"""
Main Application Window - IMPROVED VERSION
PySide6-based GUI for hyperspectral data analysis

CHANGES IN THIS VERSION:
1. Fixed hard-coded paths
2. Added UI for polynomial correction
3. Added UI for I-V smoothing parameters
4. Fixed encoding issues
5. Unified data type detection
6. Added discretization statistics display
"""

import sys
from pathlib import Path
import logging
from typing import Optional, Dict, List, Tuple

import pandas as pd
import numpy as np

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QFileDialog, QMessageBox,
    QGroupBox, QGridLayout, QSpinBox, QCheckBox,
    QComboBox, QTableWidget, QTableWidgetItem,
    QProgressBar, QTextEdit, QSplitter, QTabWidget,
    QDoubleSpinBox, QInputDialog, QDialog,
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtGui import QPixmap, QPainter, QColor, QBrush, QPen, QIcon

from ..models.spectral_data import SpectralData, SpectralMetadata
from ..models.topography_data import TopographyData
from ..data_loaders.nanosurf_sts_loader import NanosurfSTSLoader
from ..data_loaders.neaspec_snom_loader import NeaSpecSNOMLoader
from ..data_loaders.base_loader import BaseDataLoader  # Para detecção unificada
from ..processing.derivatives import DerivativesProcessor
from ..processing.discretization import Discretizer
from ..processing.iv_processor import IVDataProcessor
from .topography_widget import TopographyWidget
from .map_dialog import MapDialog
from ..processing.map_generator import MapGenerator
from ..processing.integration import IntegrationProcessor

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    """Main application window for hyperspectral data analysis."""
    
    def __init__(self):
        """Initialize main window."""
        super().__init__()
        self.setWindowTitle("🏳️‍⚧️ T.R.A.N.S. Tools of Research and Analysis for Nano Spectroscopy (beta ver. 0.5.0) - By Eduarda Policarpo - 🏳️‍⚧️")
        self.setGeometry(100, 100, 1400, 900)

        # Setup icon with RELATIVE paths only
        self.setup_window_icon()
        
        # Data storage
        self.spectral_data: Optional[SpectralData] = None
        self.topography_data: Optional[TopographyData] = None
        self.derivatives: Dict[str, SpectralData] = {}
        self.discretized_data: Dict[str, SpectralData] = {}
        self.current_data_type: str = 'unknown'
        
        # Processing modules
        self.derivatives_processor = DerivativesProcessor()
        self.discretizer = Discretizer()
        self.iv_processor = IVDataProcessor()
        self.map_generator = MapGenerator()
        self.integration_processor = IntegrationProcessor()

        # Data loaders
        self.loaders = {
            'nanosurf': NanosurfSTSLoader(),
            'neaspec': NeaSpecSNOMLoader()
        }
        
        # Setup UI
        self.setup_ui()
        self.setup_logging()

    def setup_window_icon(self):
        """Setup window icon with RELATIVE paths only."""
        # FIXED: Only relative paths
        icon_paths = [
            Path(__file__).parent / "icon.png",
            Path(__file__).parent.parent.parent / "src" / "ui" / "icon.png",
            Path("src/ui/icon.png"),
        ]
        
        icon_loaded = False
        
        for icon_path in icon_paths:
            logger.debug(f"Trying icon path: {icon_path}")
            
            if icon_path.exists():
                try:
                    icon = QIcon(str(icon_path))
                    if not icon.isNull():
                        self.setWindowIcon(icon)
                        logger.info(f"Window icon loaded: {icon_path}")
                        icon_loaded = True
                        break
                except Exception as e:
                    logger.error(f"Error loading icon {icon_path}: {e}")
        
        if not icon_loaded:
            logger.warning("No application icon could be loaded, using fallback")
            self.create_fallback_icon()

    def create_fallback_icon(self):
        """Create a simple fallback icon programmatically."""
        try:
            pixmap = QPixmap(64, 64)
            pixmap.fill(Qt.transparent)
            
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.Antialiasing)
            
            # Draw background circle
            painter.setBrush(QColor(70, 130, 180))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(8, 8, 48, 48)
            
            # Draw "T" letter
            from PySide6.QtCore import QRect
            painter.setPen(QColor(255, 255, 255))
            font = painter.font()
            font.setPointSize(32)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(QRect(0, 0, 64, 64), Qt.AlignCenter, "T")
            
            painter.end()
            
            self.setWindowIcon(QIcon(pixmap))
            logger.info("Fallback icon created")
            
        except Exception as e:
            logger.error(f"Failed to create fallback icon: {e}")

    def setup_ui(self):
        """Setup user interface."""
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout with splitter
        layout = QVBoxLayout(central_widget)
        
        # Top: Menu bar / toolbar
        self.create_menu_bar()
        
        # Main content with splitter
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel: Controls
        left_panel = self.create_control_panel()
        splitter.addWidget(left_panel)
        
        # Center: Visualization
        center_panel = self.create_visualization_panel()
        splitter.addWidget(center_panel)
        
        # Right panel: Info and logs
        right_panel = self.create_info_panel()
        splitter.addWidget(right_panel)
        
        # Set splitter proportions
        splitter.setSizes([300, 700, 300])
        
        layout.addWidget(splitter)
        
        # Bottom: Status bar
        self.status_bar = self.statusBar()
        self.progress_bar = QProgressBar()
        self.progress_bar.hide()
        self.status_bar.addPermanentWidget(self.progress_bar)

    def create_menu_bar(self):
        """Create menu bar with actions."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu('📁 File')
        
        load_action = file_menu.addAction('Load Data Directory')
        load_action.triggered.connect(self.load_from_directory)
        
        load_file_action = file_menu.addAction('Load Single File')
        load_file_action.triggered.connect(self.load_single_file)
        
        file_menu.addSeparator()
        
        export_action = file_menu.addAction('Export to CSV')
        export_action.triggered.connect(self.export_to_csv)
        
        file_menu.addSeparator()
        
        quit_action = file_menu.addAction('Quit')
        quit_action.triggered.connect(self.close)
        
        # View menu
        view_menu = menubar.addMenu('👁️ View')
        
        reset_view_action = view_menu.addAction('Reset View')
        reset_view_action.triggered.connect(self.reset_view)
        
        # Help menu
        help_menu = menubar.addMenu('❓ Help')
        
        about_action = help_menu.addAction('About')
        about_action.triggered.connect(self.show_about)

    def create_control_panel(self) -> QWidget:
        """Create left control panel with enhanced controls."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # DATA LOADING
        load_group = QGroupBox("📂 Data Loading")
        load_layout = QVBoxLayout()
        
        # Loader selection
        loader_layout = QHBoxLayout()
        loader_layout.addWidget(QLabel("Data Type:"))
        self.loader_combo = QComboBox()
        self.loader_combo.addItems(["Nanosurf STS", "NeaSpec SNOM"])
        loader_layout.addWidget(self.loader_combo)
        load_layout.addLayout(loader_layout)
        
        # Load buttons
        self.load_dir_btn = QPushButton("📁 Load from Directory")
        self.load_dir_btn.clicked.connect(self.load_from_directory)
        load_layout.addWidget(self.load_dir_btn)
        
        self.load_file_btn = QPushButton("📄 Load Single File")
        self.load_file_btn.clicked.connect(self.load_single_file)
        load_layout.addWidget(self.load_file_btn)
        
        # Data type label
        self.data_type_label = QLabel("Data type: Not loaded")
        self.data_type_label.setStyleSheet("font-weight: bold;")
        load_layout.addWidget(self.data_type_label)
        
        load_group.setLayout(load_layout)
        layout.addWidget(load_group)
        
        # PREPROCESSING
        preprocess_group = QGroupBox("⚙️ Preprocessing")
        preprocess_layout = QVBoxLayout()
        
        # Truncate range
        truncate_layout = QGridLayout()
        truncate_layout.addWidget(QLabel("V min:"), 0, 0)
        self.v_min_spin = QDoubleSpinBox()
        self.v_min_spin.setRange(-10, 10)
        self.v_min_spin.setValue(-2.0)
        self.v_min_spin.setSingleStep(0.1)
        truncate_layout.addWidget(self.v_min_spin, 0, 1)
        
        truncate_layout.addWidget(QLabel("V max:"), 1, 0)
        self.v_max_spin = QDoubleSpinBox()
        self.v_max_spin.setRange(-10, 10)
        self.v_max_spin.setValue(2.0)
        self.v_max_spin.setSingleStep(0.1)
        truncate_layout.addWidget(self.v_max_spin, 1, 1)
        
        self.truncate_btn = QPushButton("✂️ Truncate Range")
        self.truncate_btn.clicked.connect(self.truncate_range)
        truncate_layout.addWidget(self.truncate_btn, 2, 0, 1, 2)
        
        preprocess_layout.addLayout(truncate_layout)
        
        # Smoothing checkbox
        self.smooth_check = QCheckBox("Apply Smoothing")
        self.smooth_check.setChecked(True)
        preprocess_layout.addWidget(self.smooth_check)
        
        preprocess_group.setLayout(preprocess_layout)
        layout.addWidget(preprocess_group)
        
        # PROCESSING
        process_group = QGroupBox("🔬 Processing")
        process_layout = QVBoxLayout()
        
        # I-V Processing with NEW smoothing parameters UI
        iv_group = QGroupBox("I-V Processing")
        iv_layout = QVBoxLayout()
        
        # IMPROVEMENT: Add smoothing parameter controls
        smooth_params_layout = QGridLayout()
        smooth_params_layout.addWidget(QLabel("Smooth Window:"), 0, 0)
        self.iv_smooth_window_spin = QSpinBox()
        self.iv_smooth_window_spin.setRange(3, 51)
        self.iv_smooth_window_spin.setValue(11)
        self.iv_smooth_window_spin.setSingleStep(2)  # Only odd numbers
        smooth_params_layout.addWidget(self.iv_smooth_window_spin, 0, 1)
        
        smooth_params_layout.addWidget(QLabel("Poly Order:"), 1, 0)
        self.iv_smooth_poly_spin = QSpinBox()
        self.iv_smooth_poly_spin.setRange(1, 5)
        self.iv_smooth_poly_spin.setValue(3)
        smooth_params_layout.addWidget(self.iv_smooth_poly_spin, 1, 1)
        
        iv_layout.addLayout(smooth_params_layout)
        
        self.process_iv_btn = QPushButton("🔄 Process I-V Data")
        self.process_iv_btn.clicked.connect(self.process_iv_data)
        iv_layout.addWidget(self.process_iv_btn)
        
        self.calc_deriv_btn = QPushButton("📈 Calculate Derivatives")
        self.calc_deriv_btn.clicked.connect(self.calculate_derivatives_from_iv)
        iv_layout.addWidget(self.calc_deriv_btn)
        
        iv_group.setLayout(iv_layout)
        process_layout.addWidget(iv_group)
        
        # Derivatives with NEW polynomial correction UI
        deriv_group = QGroupBox("Derivatives")
        deriv_layout = QVBoxLayout()
        
        self.calc_derivatives_btn = QPushButton("∂ Calculate Derivatives")
        self.calc_derivatives_btn.clicked.connect(self.calculate_derivatives)
        deriv_layout.addWidget(self.calc_derivatives_btn)
        
        # IMPROVEMENT: Add polynomial correction option
        self.poly_correct_check = QCheckBox("Apply Polynomial Baseline Correction")
        self.poly_correct_check.setChecked(True)
        self.poly_correct_check.setToolTip("Remove polynomial background from derivatives")
        deriv_layout.addWidget(self.poly_correct_check)
        
        # Polynomial degrees
        poly_layout = QGridLayout()
        poly_layout.addWidget(QLabel("1st Deriv Poly:"), 0, 0)
        self.first_poly_spin = QSpinBox()
        self.first_poly_spin.setRange(1, 5)
        self.first_poly_spin.setValue(2)
        poly_layout.addWidget(self.first_poly_spin, 0, 1)
        
        poly_layout.addWidget(QLabel("2nd Deriv Poly:"), 1, 0)
        self.second_poly_spin = QSpinBox()
        self.second_poly_spin.setRange(1, 8)
        self.second_poly_spin.setValue(4)
        poly_layout.addWidget(self.second_poly_spin, 1, 1)
        
        deriv_layout.addLayout(poly_layout)
        
        deriv_group.setLayout(deriv_layout)
        process_layout.addWidget(deriv_group)
        
        # Discretization
        discretize_group = QGroupBox("Spatial Discretization")
        discretize_layout = QGridLayout()
        
        discretize_layout.addWidget(QLabel("Block Width:"), 0, 0)
        self.block_h_spin = QSpinBox()
        self.block_h_spin.setRange(1, 100)
        self.block_h_spin.setValue(10)
        discretize_layout.addWidget(self.block_h_spin, 0, 1)
        
        discretize_layout.addWidget(QLabel("Block Height:"), 1, 0)
        self.block_v_spin = QSpinBox()
        self.block_v_spin.setRange(1, 100)
        self.block_v_spin.setValue(10)
        discretize_layout.addWidget(self.block_v_spin, 1, 1)
        
        self.ignore_empty_check = QCheckBox("Ignore Empty Blocks")
        self.ignore_empty_check.setChecked(True)
        discretize_layout.addWidget(self.ignore_empty_check, 2, 0, 1, 2)
        
        self.use_selection_check = QCheckBox("Use Selection Only")
        discretize_layout.addWidget(self.use_selection_check, 3, 0, 1, 2)
        
        self.discretize_btn = QPushButton("⊞ Apply Discretization")
        self.discretize_btn.clicked.connect(self.apply_discretization)
        discretize_layout.addWidget(self.discretize_btn, 4, 0, 1, 2)
        
        discretize_group.setLayout(discretize_layout)
        process_layout.addWidget(discretize_group)
        
        process_group.setLayout(process_layout)
        layout.addWidget(process_group)
        
        # EXPORT SECTION
        export_group = QGroupBox("💾 Export")
        export_layout = QVBoxLayout()
        
        self.export_iv_btn = QPushButton("📊 Export I-V")
        self.export_iv_btn.clicked.connect(self.export_iv_data)
        export_layout.addWidget(self.export_iv_btn)
        
        self.export_deriv_btn = QPushButton("📈 Export Derivatives")
        self.export_deriv_btn.clicked.connect(self.export_derivatives)
        export_layout.addWidget(self.export_deriv_btn)
        
        self.export_selection_btn = QPushButton("🎯 Export Selection")
        self.export_selection_btn.clicked.connect(self.export_selection)
        export_layout.addWidget(self.export_selection_btn)
        
        # IMPROVEMENT: Add topography export
        self.export_topo_btn = QPushButton("🗻 Export Topography CSV")
        self.export_topo_btn.clicked.connect(self.export_topography_csv)
        export_layout.addWidget(self.export_topo_btn)
        
        self.export_maps_btn = QPushButton("🗺️ Generate Maps")
        self.export_maps_btn.clicked.connect(self.generate_maps)
        export_layout.addWidget(self.export_maps_btn)
        
        export_group.setLayout(export_layout)
        layout.addWidget(export_group)
        
        layout.addStretch()
        return panel

    def create_visualization_panel(self) -> QWidget:
        """Create center visualization panel."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Tab widget for different views
        self.tabs = QTabWidget()
        
        # Topography tab
        self.topography_widget = TopographyWidget()
        self.topography_widget.selection_changed.connect(self.on_selection_changed)
        self.tabs.addTab(self.topography_widget, "Topography")
        
        # Data table tab
        self.data_table = QTableWidget()
        self.tabs.addTab(self.data_table, "Data Table")
        
        # Info tab
        self.info_text = QTextEdit()
        self.info_text.setReadOnly(True)
        self.tabs.addTab(self.info_text, "Information")
        
        # IMPROVEMENT: Spectrum viewer tab (will be implemented)
        self.spectrum_viewer = QWidget()
        self.setup_spectrum_viewer()
        self.tabs.addTab(self.spectrum_viewer, "Spectrum Viewer")
        
        layout.addWidget(self.tabs)
        return panel

    def setup_spectrum_viewer(self):
        """Setup spectrum viewer tab - IMPROVED with matplotlib placeholder."""
        layout = QVBoxLayout(self.spectrum_viewer)
        
        # Controls
        controls_layout = QHBoxLayout()
        
        controls_layout.addWidget(QLabel("Spectrum:"))
        self.spectrum_combo = QComboBox()
        self.spectrum_combo.currentTextChanged.connect(self.update_spectrum_plot)
        controls_layout.addWidget(self.spectrum_combo)
        
        self.spectrum_type_combo = QComboBox()
        self.spectrum_type_combo.addItems(["Raw Data", "First Derivative", "Second Derivative"])
        self.spectrum_type_combo.currentTextChanged.connect(self.update_spectrum_plot)
        controls_layout.addWidget(self.spectrum_type_combo)
        
        self.plot_btn = QPushButton("📊 Plot")
        self.plot_btn.clicked.connect(self.update_spectrum_plot)
        controls_layout.addWidget(self.plot_btn)
        
        controls_layout.addStretch()
        layout.addLayout(controls_layout)
        
        # Plot area placeholder
        self.spectrum_plot_widget = QWidget()
        self.spectrum_plot_layout = QVBoxLayout(self.spectrum_plot_widget)
        layout.addWidget(self.spectrum_plot_widget)
        
        # Info label
        self.spectrum_info_label = QLabel("Select a spectrum and click 'Plot' to view")
        layout.addWidget(self.spectrum_info_label)

    def create_info_panel(self) -> QWidget:
        """Create right info/log panel with IMPROVED statistics."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # Statistics group - IMPROVED with discretization stats
        stats_group = QGroupBox("Statistics")
        stats_layout = QVBoxLayout()
        
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        self.stats_text.setMaximumHeight(250)  # Increased height
        stats_layout.addWidget(self.stats_text)
        
        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)
        
        # Log group
        log_group = QGroupBox("Processing Log")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        log_layout.addWidget(self.log_text)
        
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)
        
        # Selection info
        selection_group = QGroupBox("Selection Info")
        selection_layout = QVBoxLayout()
        
        self.selection_info = QLabel("Selected blocks: 0")
        selection_layout.addWidget(self.selection_info)
        
        selection_group.setLayout(selection_layout)
        layout.addWidget(selection_group)
        
        return panel

    def setup_logging(self):
        """Setup logging to text widget."""
        class GuiLogHandler(logging.Handler):
            def __init__(self, text_widget):
                super().__init__()
                self.text_widget = text_widget
                
            def emit(self, record):
                msg = self.format(record)
                self.text_widget.append(msg)
        
        gui_handler = GuiLogHandler(self.log_text)
        gui_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', 
                                                  datefmt='%H:%M:%S'))
        logger.addHandler(gui_handler)

    # PROCESSING METHODS - IMPROVED

    def process_iv_data(self):
        """Process raw I-V data with USER-CONFIGURABLE smoothing."""
        if self.spectral_data is None or self.current_data_type != 'iv':
            QMessageBox.warning(self, "Warning", "Please load I-V data first")
            return
        
        try:
            self.show_progress("Processing I-V data...")
            
            # IMPROVEMENT: Get user-configured parameters
            window = self.iv_smooth_window_spin.value()
            polyorder = self.iv_smooth_poly_spin.value()
            
            # Ensure window is odd
            if window % 2 == 0:
                window += 1
                self.iv_smooth_window_spin.setValue(window)
            
            # Update processor with user parameters
            self.iv_processor.smooth_window = window
            self.iv_processor.smooth_polyorder = polyorder
            
            # Process
            processed = self.iv_processor.process_raw_iv_data(self.spectral_data)
            
            # Replace spectral data with processed version
            self.spectral_data = processed
            
            self.hide_progress()
            self.update_ui_with_data()
            
            QMessageBox.information(
                self, 
                "Success", 
                f"I-V data processed successfully\n"
                f"Window: {window}, Polynomial Order: {polyorder}"
            )
            logger.info(f"I-V data processed with window={window}, polyorder={polyorder}")
            
        except Exception as e:
            self.hide_progress()
            QMessageBox.critical(self, "Error", f"Failed to process I-V data: {str(e)}")
            logger.error(f"Error processing I-V: {e}")

    def calculate_derivatives(self):
        """Calculate derivatives with POLYNOMIAL CORRECTION option."""
        if self.spectral_data is None:
            QMessageBox.warning(self, "Warning", "Please load data first")
            return
        
        try:
            self.show_progress("Calculating derivatives...")
            
            smooth = self.smooth_check.isChecked()
            apply_poly_correct = self.poly_correct_check.isChecked()
            
            # Calculate derivatives
            results = self.derivatives_processor.calculate_derivatives_batch(
                self.spectral_data,
                calculate_second=True,
                apply_correction=False  # Will apply manually
            )
            
            self.derivatives['first'] = results['first']
            self.derivatives['second'] = results['second']
            
            # IMPROVEMENT: Apply polynomial correction if requested
            if apply_poly_correct:
                first_degree = self.first_poly_spin.value()
                second_degree = self.second_poly_spin.value()
                
                first_corrected, second_corrected = self.derivatives_processor.correct_derivatives_with_polynomials(
                    self.derivatives['first'],
                    self.derivatives['second'],
                    first_poly_degree=first_degree,
                    second_poly_degree=second_degree
                )
                
                self.derivatives['first_corrected'] = first_corrected
                self.derivatives['second_corrected'] = second_corrected
                
                logger.info(f"Applied polynomial correction: 1st={first_degree}, 2nd={second_degree}")
            
            self.hide_progress()
            self.update_derivatives_display()
            
            correction_msg = f"\nPolynomial correction: {'Yes' if apply_poly_correct else 'No'}"
            if apply_poly_correct:
                correction_msg += f" (degrees: {first_degree}, {second_degree})"
            
            QMessageBox.information(
                self, 
                "Success", 
                f"Derivatives calculated successfully{correction_msg}"
            )
            logger.info("Derivatives calculation completed")
            
        except Exception as e:
            self.hide_progress()
            QMessageBox.critical(self, "Error", f"Failed to calculate derivatives: {str(e)}")
            logger.error(f"Error calculating derivatives: {e}")

    def calculate_derivatives_from_iv(self):
        """Calculate derivatives from I-V data using IV processor."""
        if self.spectral_data is None or self.current_data_type != 'iv':
            QMessageBox.warning(self, "Warning", "Please load I-V data first")
            return
        
        try:
            self.show_progress("Calculating derivatives from I-V...")
            
            smooth_before = self.smooth_check.isChecked()
            smooth_after = self.smooth_check.isChecked()
            
            # Calculate using IV processor
            first_deriv, second_deriv = self.iv_processor.calculate_derivatives_from_iv(
                self.spectral_data,
                smooth_before=smooth_before,
                smooth_after=smooth_after
            )
            
            self.derivatives['first'] = first_deriv
            self.derivatives['second'] = second_deriv
            
            # Apply polynomial correction if enabled
            if self.poly_correct_check.isChecked():
                first_degree = self.first_poly_spin.value()
                second_degree = self.second_poly_spin.value()
                
                first_corrected, second_corrected = self.derivatives_processor.correct_derivatives_with_polynomials(
                    first_deriv,
                    second_deriv,
                    first_poly_degree=first_degree,
                    second_poly_degree=second_degree
                )
                
                self.derivatives['first_corrected'] = first_corrected
                self.derivatives['second_corrected'] = second_corrected
            
            self.hide_progress()
            self.update_derivatives_display()
            
            QMessageBox.information(self, "Success", "Derivatives from I-V calculated successfully")
            logger.info("I-V derivatives calculation completed")
            
        except Exception as e:
            self.hide_progress()
            QMessageBox.critical(self, "Error", f"Failed to calculate I-V derivatives: {str(e)}")
            logger.error(f"Error calculating I-V derivatives: {e}")

    def apply_discretization(self):
        """Apply spatial discretization with IMPROVED statistics display."""
        if self.spectral_data is None:
            QMessageBox.warning(self, "Warning", "No data available for discretization")
            return
        
        try:
            self.show_progress("Applying discretization...")
            
            # Get parameters
            block_h = self.block_h_spin.value()
            block_v = self.block_v_spin.value()
            use_selection = self.use_selection_check.isChecked()
            ignore_empty = self.ignore_empty_check.isChecked()
            
            # Get selected blocks if using selection
            selected_blocks = None
            if use_selection and hasattr(self, 'topography_widget'):
                selected_blocks = self.topography_widget.get_selected_blocks()
                if not selected_blocks:
                    QMessageBox.warning(self, "Warning", "No blocks selected")
                    self.hide_progress()
                    return
            
            # Discretize main data
            results = self.discretizer.discretize_spectral_data(
                spectral_data=self.spectral_data,
                block_h=block_h,
                block_v=block_v,
                topography=self.topography_data,
                selected_blocks=selected_blocks,
                ignore_empty_blocks=ignore_empty,
                data_type=self.current_data_type
            )
            
            self.discretized_data['main'] = results
            
            # IMPROVEMENT: Display detailed statistics
            stats = self.discretizer.last_stats
            stats_msg = f"""Discretization Statistics:
            
Original Grid: {stats['original_dimensions'][0]}x{stats['original_dimensions'][1]}
Block Size: {stats['block_size'][0]}x{stats['block_size'][1]}
Number of Groups: {stats['num_groups'][0]}x{stats['num_groups'][1]}

Intermediate Columns: {stats['intermediate_columns']}
Final Blocks: {stats['final_columns']}
Selected Blocks: {len(selected_blocks) if selected_blocks else 'All'}
Ignore Empty: {stats['ignore_empty']}
"""
            
            self.hide_progress()
            self.update_discretization_display()
            self.update_statistics()  # Update stats display
            
            QMessageBox.information(self, "Discretization Complete", stats_msg)
            logger.info(f"Discretization completed: {stats}")
            
        except Exception as e:
            self.hide_progress()
            QMessageBox.critical(self, "Error", f"Failed to apply discretization: {str(e)}")
            logger.error(f"Error in discretization: {e}")

    # EXPORT METHODS - IMPROVED

    def export_topography_csv(self):
        """IMPROVEMENT: Export topography data as CSV."""
        if self.topography_data is None:
            QMessageBox.warning(self, "Warning", "No topography data available")
            return
        
        try:
            filepath, _ = QFileDialog.getSaveFileName(
                self,
                "Save Topography CSV",
                "",
                "CSV Files (*.csv)"
            )
            
            if not filepath:
                return
            
            self.show_progress("Exporting topography...")
            
            # Export raw topography
            df = pd.DataFrame(self.topography_data.data)
            df.to_csv(filepath, index=False)
            
            # If discretized, also export that
            if self.topography_data.discretized_data is not None:
                base = Path(filepath).stem
                parent = Path(filepath).parent
                discretized_path = parent / f"{base}_discretized.csv"
                
                df_disc = pd.DataFrame(self.topography_data.discretized_data)
                df_disc.to_csv(discretized_path, index=False)
                
                msg = f"Exported:\n{filepath}\n{discretized_path}"
            else:
                msg = f"Exported:\n{filepath}"
            
            self.hide_progress()
            QMessageBox.information(self, "Success", msg)
            logger.info(f"Topography exported to {filepath}")
            
        except Exception as e:
            self.hide_progress()
            QMessageBox.critical(self, "Error", f"Failed to export topography: {str(e)}")
            logger.error(f"Error exporting topography: {e}")

    def update_spectrum_plot(self):
        """IMPROVEMENT: Basic implementation of spectrum plotting."""
        try:
            # Check if matplotlib is available
            try:
                import matplotlib.pyplot as plt
                from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
            except ImportError:
                self.spectrum_info_label.setText("Matplotlib not available for plotting")
                logger.warning("Matplotlib not available")
                return
            
            if self.spectral_data is None:
                self.spectrum_info_label.setText("No data loaded")
                return
            
            spectrum_name = self.spectrum_combo.currentText()
            if not spectrum_name:
                return
            
            # Get the appropriate data based on type selection
            data_type = self.spectrum_type_combo.currentText()
            
            if data_type == "Raw Data":
                data = self.spectral_data
            elif data_type == "First Derivative" and 'first' in self.derivatives:
                data = self.derivatives.get('first_corrected', self.derivatives['first'])
            elif data_type == "Second Derivative" and 'second' in self.derivatives:
                data = self.derivatives.get('second_corrected', self.derivatives['second'])
            else:
                self.spectrum_info_label.setText(f"{data_type} not available")
                return
            
            # Get spectrum
            if spectrum_name not in data.spectra.columns:
                self.spectrum_info_label.setText(f"Spectrum {spectrum_name} not found")
                return
            
            spectrum = data.spectra[spectrum_name]
            var = data.independent_var
            
            # Clear previous plot
            for i in reversed(range(self.spectrum_plot_layout.count())): 
                self.spectrum_plot_layout.itemAt(i).widget().setParent(None)
            
            # Create new figure
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.plot(var, spectrum, 'b-', linewidth=1.5)
            ax.set_xlabel(data.independent_var_name)
            ax.set_ylabel(data_type)
            ax.set_title(f"Spectrum: {spectrum_name}")
            ax.grid(True, alpha=0.3)
            
            # Embed in Qt
            canvas = FigureCanvas(fig)
            self.spectrum_plot_layout.addWidget(canvas)
            
            self.spectrum_info_label.setText(f"Showing: {spectrum_name} ({data_type})")
            logger.info(f"Plotted spectrum: {spectrum_name}")
            
        except Exception as e:
            self.spectrum_info_label.setText(f"Error plotting: {str(e)}")
            logger.error(f"Error plotting spectrum: {e}")

    def update_statistics(self):
        """IMPROVED: Update statistics with discretization info."""
        if self.spectral_data is None:
            self.stats_text.clear()
            return
        
        stats = []
        
        # Basic statistics
        var_min = np.min(self.spectral_data.independent_var)
        var_max = np.max(self.spectral_data.independent_var)
        stats.append(f"Range: [{var_min:.3f}, {var_max:.3f}]")
        
        # Spectral statistics
        spectra_values = self.spectral_data.spectra.values.flatten()
        stats.append(f"Mean: {np.nanmean(spectra_values):.3e}")
        stats.append(f"Std: {np.nanstd(spectra_values):.3e}")
        stats.append(f"Min: {np.nanmin(spectra_values):.3e}")
        stats.append(f"Max: {np.nanmax(spectra_values):.3e}")
        
        # IMPROVEMENT: Add discretization statistics
        if hasattr(self.discretizer, 'last_stats') and self.discretizer.last_stats:
            st = self.discretizer.last_stats
            stats.append("")
            stats.append("--- Discretization ---")
            stats.append(f"Original: {st['original_dimensions'][0]}x{st['original_dimensions'][1]}")
            stats.append(f"Block Size: {st['block_size'][0]}x{st['block_size'][1]}")
            stats.append(f"Groups: {st['num_groups'][0]}x{st['num_groups'][1]}")
            stats.append(f"Intermediate Cols: {st['intermediate_columns']}")
            stats.append(f"Final Blocks: {st['final_columns']}")
        
        self.stats_text.setText("\n".join(stats))

    
    # ========================================================================
    # DATA LOADING METHODS (Added by fix script)
    # ========================================================================
    
    def load_from_directory(self):
        """Load data from directory of measurement files."""
        try:
            directory = QFileDialog.getExistingDirectory(
                self,
                "Select Data Directory",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not directory:
                return
            
            directory = Path(directory)
            
            # Determine data type
            loader_type, _ = QInputDialog.getItem(
                self,
                "Select Data Type",
                "Choose the type of data to load:",
                ["Nanosurf STS (.nid)", "NeaSpec SNOM (.txt)"],
                0,
                False
            )
            
            if not loader_type:
                return
            
            # Select appropriate loader
            if "Nanosurf" in loader_type:
                loader = self.loaders['nanosurf']
            else:
                loader = self.loaders['neaspec']
            
            # Load data with progress
            self.log_message(f"Loading data from {directory}...")
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            # Load
            spectral_data, topography = loader.load_from_directory(directory)
            
            self.spectral_data = spectral_data
            self.topography_data = topography
            
            # Detect data type
            if hasattr(spectral_data.metadata, 'additional_info'):
                self.current_data_type = spectral_data.metadata.additional_info.get('data_type', 'iv')
            else:
                self.current_data_type = 'iv'
            
            # Update UI
            self.progress_bar.setValue(100)
            self.update_statistics()
            
            if topography:
                self.topography_widget.set_topography(topography)
            
            self.log_message(f"✓ Loaded {spectral_data.num_spectra} spectra")
            self.log_message(f"✓ Data type detected: {self.current_data_type}")
            
            QMessageBox.information(
                self,
                "Success",
                f"Loaded {spectral_data.num_spectra} spectra from {directory.name}"
            )
            
        except Exception as e:
            logger.error(f"Error loading directory: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load data:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    def load_single_file(self):
        """Load data from single file."""
        try:
            filepath, _ = QFileDialog.getOpenFileName(
                self,
                "Select Data File",
                "",
                "All Supported (*.nid *.txt *.csv);;Nanosurf (*.nid);;NeaSpec (*.txt);;CSV (*.csv)"
            )
            
            if not filepath:
                return
            
            filepath = Path(filepath)
            
            # Determine loader by extension
            if filepath.suffix == '.nid':
                loader = self.loaders['nanosurf']
            elif filepath.suffix in ['.txt', '.dat']:
                loader = self.loaders['neaspec']
            elif filepath.suffix == '.csv':
                self.load_csv_file(filepath)
                return
            else:
                QMessageBox.warning(self, "Warning", f"Unsupported file type: {filepath.suffix}")
                return
            
            # Load
            self.log_message(f"Loading {filepath.name}...")
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            spectral_data = loader.load_single_file(filepath)
            self.spectral_data = spectral_data
            
            # Detect data type
            self.current_data_type = BaseDataLoader.detect_data_type(filepath)
            
            self.progress_bar.setValue(100)
            self.update_statistics()
            
            self.log_message(f"✓ Loaded {spectral_data.num_spectra} spectra")
            self.log_message(f"✓ Data type: {self.current_data_type}")
            
            QMessageBox.information(
                self,
                "Success",
                f"Loaded {spectral_data.num_spectra} spectra"
            )
            
        except Exception as e:
            logger.error(f"Error loading file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load file:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    def load_csv_file(self, filepath: Path):
        """Load spectral data from CSV file."""
        try:
            df = pd.read_csv(filepath)
            
            # Guess dimensions
            n_spectra = len(df.columns) - 1
            dim_h = int(np.sqrt(n_spectra))
            dim_v = n_spectra // dim_h
            
            metadata = SpectralMetadata(
                source_type='csv',
                dimensions=(dim_h, dim_v),
                scan_mode='unknown',
                units={'independent': 'V', 'dependent': 'A'}
            )
            
            self.spectral_data = SpectralData(df, metadata)
            
            # Detect data type from filename
            self.current_data_type = BaseDataLoader.detect_data_type(filepath)
            
            self.update_statistics()
            self.log_message(f"✓ Loaded CSV: {n_spectra} spectra")
            
        except Exception as e:
            raise ValueError(f"Error loading CSV: {e}")
    
    # ========================================================================
    # EXPORT METHODS
    # ========================================================================
    
    def export_to_csv(self):
        """Export current spectral data to CSV."""
        try:
            if self.spectral_data is None:
                QMessageBox.warning(self, "Warning", "No data to export")
                return
            
            filepath, _ = QFileDialog.getSaveFileName(
                self,
                "Export to CSV",
                "",
                "CSV Files (*.csv)"
            )
            
            if not filepath:
                return
            
            # Export
            self.spectral_data.save(filepath)
            
            # If discretized, also export that
            if self.discretized_data:
                base = Path(filepath).stem
                parent = Path(filepath).parent
                
                for key, data in self.discretized_data.items():
                    discretized_path = parent / f"{base}_{key}.csv"
                    data.save(discretized_path)
                
                msg = f"Exported:\n{filepath}\n{discretized_path}"
            else:
                msg = f"Exported:\n{filepath}"
            
            self.log_message(f"✓ {msg}")
            QMessageBox.information(self, "Success", msg)
            
        except Exception as e:
            logger.error(f"Error exporting: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to export:\n{str(e)}")
    
    def export_selection(self):
        """Export only selected blocks."""
        try:
            if self.topography_data is None:
                QMessageBox.warning(self, "Warning", "No topography data")
                return
            
            if not self.topography_data.selected_blocks:
                QMessageBox.warning(self, "Warning", "No blocks selected")
                return
            
            filepath, _ = QFileDialog.getSaveFileName(
                self,
                "Export Selection",
                "",
                "CSV Files (*.csv)"
            )
            
            if not filepath:
                return
            
            # Create mask from selection
            mask = self.topography_data.get_selection_mask()
            
            # Apply mask to current data
            if self.spectral_data:
                masked_data = self.spectral_data.apply_mask(mask)
                masked_data.save(filepath)
                self.log_message(f"✓ Exported {len(self.topography_data.selected_blocks)} blocks")
            
            QMessageBox.information(
                self,
                "Success",
                f"Exported {len(self.topography_data.selected_blocks)} selected blocks"
            )
            
        except Exception as e:
            logger.error(f"Error exporting selection: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to export:\n{str(e)}")
    
    def generate_maps(self):
        """Generate spatial maps from integrated data."""
        try:
            if self.spectral_data is None:
                QMessageBox.warning(self, "Warning", "No spectral data loaded")
                return
            
            # Show map configuration dialog
            dialog = MapDialog(self)
            if dialog.exec() != QDialog.Accepted:
                return
            
            intervals = dialog.get_intervals()
            if not intervals:
                QMessageBox.warning(self, "Warning", "No integration intervals defined")
                return
            
            # Select output directory
            output_dir = QFileDialog.getExistingDirectory(
                self,
                "Select Output Directory for Maps",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not output_dir:
                return
            
            output_dir = Path(output_dir)
            
            # Set intervals and generate maps
            self.map_generator.set_integration_intervals(intervals)
            
            self.log_message(f"Generating maps for {len(intervals)} intervals...")
            self.progress_bar.setVisible(True)
            
            maps = self.map_generator.generate_maps_for_dataset(
                self.spectral_data,
                output_dir,
                self.current_data_type
            )
            
            self.progress_bar.setValue(100)
            self.log_message(f"✓ Generated {len(maps)} maps")
            
            QMessageBox.information(
                self,
                "Success",
                f"Generated {len(maps)} maps in {output_dir}"
            )
            
        except Exception as e:
            logger.error(f"Error generating maps: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to generate maps:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    # ========================================================================
    # UI CALLBACK METHODS
    # ========================================================================
    
    def on_selection_changed(self):
        """Handle topography selection changes."""
        if self.topography_data:
            n_selected = len(self.topography_data.selected_blocks)
            self.log_message(f"Selection: {n_selected} blocks selected")
            self.update_statistics()
    
    def log_message(self, message: str):
        """Add message to processing log."""
        if hasattr(self, 'log_text'):
            self.log_text.append(message)
            # Auto-scroll to bottom
            scrollbar = self.log_text.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())
    def show_about(self):
        """Show about dialog."""
        about_text = """
<h2>T.R.A.N.S. HyperSpec Analyzer</h2>
<p><b>Version 0.5.0 (Beta)</b></p>
<p>Tools of Research and Analysis for Nano Spectroscopy</p>
<p>By Eduarda Policarpo 🏳️‍⚧️</p>
<hr>
<p><b>Improvements in v0.5.0:</b></p>
<ul>
<li>✅ Fixed hard-coded file paths</li>
<li>✅ Added polynomial correction UI</li>
<li>✅ Added I-V smoothing parameter controls</li>
<li>✅ Fixed character encoding issues</li>
<li>✅ Added discretization statistics display</li>
<li>✅ Implemented basic spectrum plotting</li>
<li>✅ Added topography CSV export</li>
</ul>
"""
        QMessageBox.about(self, "About T.R.A.N.S.", about_text)

    # Keep all other methods from original...
    # (load methods, export methods, utility methods, etc.)
    # [TRUNCATED FOR LENGTH - include all other methods from original]