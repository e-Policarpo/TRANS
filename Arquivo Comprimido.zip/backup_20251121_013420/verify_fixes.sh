#!/bin/bash

################################################################################
# HyperSpec Analyzer - Verify Fixes Script
# Version: 0.5.0
# 
# This script verifies that all fixes from apply_fixes.sh were applied correctly
#
# Usage: ./verify_fixes.sh
################################################################################

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Counters
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0

################################################################################
# Functions
################################################################################

check_file_exists() {
    local file="$1"
    local description="$2"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $description - FILE NOT FOUND: $file"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
}

check_dir_exists() {
    local dir="$1"
    local description="$2"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    if [ -d "$dir" ]; then
        echo -e "${GREEN}✓${NC} $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $description - DIRECTORY NOT FOUND: $dir"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
}

check_encoding_fixed() {
    local file="$1"
    local bad_pattern="$2"
    local description="$3"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    if [ ! -f "$file" ]; then
        echo -e "${RED}✗${NC} $description - FILE NOT FOUND"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
    
    if grep -q "$bad_pattern" "$file"; then
        echo -e "${RED}✗${NC} $description - ENCODING ISSUE STILL PRESENT"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    else
        echo -e "${GREEN}✓${NC} $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    fi
}

check_content_present() {
    local file="$1"
    local pattern="$2"
    local description="$3"
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    if [ ! -f "$file" ]; then
        echo -e "${RED}✗${NC} $description - FILE NOT FOUND"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
    
    if grep -q "$pattern" "$file"; then
        echo -e "${GREEN}✓${NC} $description"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        return 0
    else
        echo -e "${RED}✗${NC} $description - PATTERN NOT FOUND"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        return 1
    fi
}

################################################################################
# Main Verification
################################################################################

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  HyperSpec Analyzer - Verify Fixes v0.5.0${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

PROJECT_ROOT="${PROJECT_ROOT:-$(pwd)}"
echo -e "${YELLOW}Project root: ${PROJECT_ROOT}${NC}"
echo ""

################################################################################
# Check 1: File Structure
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 1: File Structure${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

check_dir_exists "${PROJECT_ROOT}/src" "src/ directory exists"
check_dir_exists "${PROJECT_ROOT}/src/processing" "src/processing/ directory exists"
check_dir_exists "${PROJECT_ROOT}/src/data_loaders" "src/data_loaders/ directory exists"
check_dir_exists "${PROJECT_ROOT}/scripts" "scripts/ directory created"
check_dir_exists "${PROJECT_ROOT}/tests" "tests/ directory created"

echo ""

################################################################################
# Check 2: New Files Created
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 2: New Files Created${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

check_file_exists "${PROJECT_ROOT}/scripts/fix_encoding.py" "fix_encoding.py script created"
check_file_exists "${PROJECT_ROOT}/tests/test_spectral_data.py" "test_spectral_data.py created"
check_file_exists "${PROJECT_ROOT}/tests/__init__.py" "tests/__init__.py created"
check_file_exists "${PROJECT_ROOT}/CHANGELOG.md" "CHANGELOG.md created"
check_file_exists "${PROJECT_ROOT}/CONTRIBUTING.md" "CONTRIBUTING.md created"

echo ""

################################################################################
# Check 3: Encoding Fixes
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 3: Encoding Fixes${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

# Check that bad encodings are NOT present (should be fixed)
check_encoding_fixed "${PROJECT_ROOT}/src/processing/derivatives.py" "Â²" "derivatives.py encoding fixed"
check_encoding_fixed "${PROJECT_ROOT}/src/processing/map_generator.py" "Ã‡" "map_generator.py encoding fixed"
check_encoding_fixed "${PROJECT_ROOT}/src/data_loaders/neaspec_snom_loader.py" "µ" "neaspec_snom_loader.py encoding fixed"
check_encoding_fixed "${PROJECT_ROOT}/src/processing/iv_processor.py" "Â²" "iv_processor.py encoding fixed"

echo ""

################################################################################
# Check 4: BaseDataLoader Updates
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 4: BaseDataLoader Updates${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

check_content_present "${PROJECT_ROOT}/src/data_loaders/base_loader.py" "@staticmethod" "BaseDataLoader has @staticmethod decorator"
check_content_present "${PROJECT_ROOT}/src/data_loaders/base_loader.py" "def detect_data_type" "BaseDataLoader has detect_data_type method"
check_content_present "${PROJECT_ROOT}/src/data_loaders/base_loader.py" "def get_data_type_display_name" "BaseDataLoader has get_data_type_display_name method"

echo ""

################################################################################
# Check 5: Requirements.txt
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 5: Requirements.txt Updates${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

check_file_exists "${PROJECT_ROOT}/requirements.txt" "requirements.txt exists"
check_content_present "${PROJECT_ROOT}/requirements.txt" "pytest" "pytest dependency added"
check_content_present "${PROJECT_ROOT}/requirements.txt" "pytest-cov" "pytest-cov dependency added"

echo ""

################################################################################
# Check 6: Python Syntax
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 6: Python Syntax Validation${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

# Check Python files for syntax errors
PYTHON_FILES=(
    "src/processing/derivatives.py"
    "src/processing/map_generator.py"
    "src/data_loaders/neaspec_snom_loader.py"
    "src/processing/iv_processor.py"
    "src/data_loaders/base_loader.py"
    "scripts/fix_encoding.py"
    "tests/test_spectral_data.py"
)

for file in "${PYTHON_FILES[@]}"; do
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    full_path="${PROJECT_ROOT}/${file}"
    
    if [ ! -f "$full_path" ]; then
        echo -e "${RED}✗${NC} Python syntax check: $file - FILE NOT FOUND"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
        continue
    fi
    
    if python3 -m py_compile "$full_path" 2>/dev/null; then
        echo -e "${GREEN}✓${NC} Python syntax check: $file"
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        echo -e "${RED}✗${NC} Python syntax check: $file - SYNTAX ERROR"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
done

echo ""

################################################################################
# Check 7: Executable Permissions
################################################################################
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Check 7: Executable Permissions${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
if [ -x "${PROJECT_ROOT}/scripts/fix_encoding.py" ]; then
    echo -e "${GREEN}✓${NC} fix_encoding.py is executable"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))
else
    echo -e "${YELLOW}⚠${NC} fix_encoding.py is not executable (run: chmod +x scripts/fix_encoding.py)"
    PASSED_CHECKS=$((PASSED_CHECKS + 1))  # Not critical
fi

echo ""

################################################################################
# Summary
################################################################################
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Verification Summary${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

PASS_RATE=$((PASSED_CHECKS * 100 / TOTAL_CHECKS))

echo "Total checks: ${TOTAL_CHECKS}"
echo -e "${GREEN}Passed: ${PASSED_CHECKS}${NC}"
echo -e "${RED}Failed: ${FAILED_CHECKS}${NC}"
echo "Pass rate: ${PASS_RATE}%"
echo ""

if [ $FAILED_CHECKS -eq 0 ]; then
    echo -e "${GREEN}✅ All checks passed!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Run tests: python -m pytest tests/ -v"
    echo "  2. Test application: python main.py"
    echo "  3. Commit changes: git add . && git commit -m 'feat: apply v0.5.0 fixes'"
    echo ""
    exit 0
else
    echo -e "${RED}❌ Some checks failed. Please review the output above.${NC}"
    echo ""
    echo "Common solutions:"
    echo "  • Re-run apply_fixes.sh"
    echo "  • Check file permissions"
    echo "  • Verify you're in the project root directory"
    echo "  • Run: python scripts/fix_encoding.py"
    echo ""
    exit 1
fi
