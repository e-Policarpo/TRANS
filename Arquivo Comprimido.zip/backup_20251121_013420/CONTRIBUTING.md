# Contributing to HyperSpec Analyzer

Thank you for your interest in contributing! 🎉

## Coding Standards

### Python Style Guide
- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/)
- Use type hints where appropriate
- Keep lines under 100 characters when possible
- Use descriptive variable names (no single letters except loop counters)

### Documentation
- Add docstrings to all public classes and methods
- Use Google-style docstrings format
- Include type information in docstrings
- Add inline comments for complex logic

Example:
```python
def calculate_derivative(data: np.ndarray, dx: float) -> np.ndarray:
    """
    Calculate numerical derivative using central differences.
    
    Parameters:
    -----------
    data : np.ndarray
        Input data array
    dx : float
        Step size
        
    Returns:
    --------
    derivative : np.ndarray
        Calculated derivative
    """
    # Implementation here
    pass
```

### Testing
- Write unit tests for new features
- Aim for >80% code coverage
- Test edge cases and error conditions
- Use pytest fixtures for common setup

### Git Workflow
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Write/update tests
5. Ensure all tests pass (`python -m pytest tests/ -v`)
6. Commit with descriptive messages
7. Push to your fork
8. Open a Pull Request

### Commit Messages
Use conventional commits format:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `test:` Test additions/changes
- `refactor:` Code refactoring
- `style:` Code style changes (formatting, etc.)
- `chore:` Maintenance tasks

Example:
```
feat: add polynomial baseline correction UI

- Added checkbox to enable/disable correction
- Added spinboxes for polynomial degrees
- Updated processing pipeline to use new settings
```

## Development Setup

```bash
# Clone repository
git clone https://github.com/your-username/hyperspec-analyzer.git
cd hyperspec-analyzer

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows

# Install development dependencies
pip install -r requirements.txt
pip install -e .  # Install in editable mode

# Run tests
python -m pytest tests/ -v

# Run with coverage
python -m pytest tests/ --cov=src --cov-report=html
```

## Code Review Process

All submissions require review. We use GitHub pull requests for this purpose.

### PR Checklist
- [ ] Code follows style guidelines
- [ ] Documentation is updated
- [ ] Tests are added/updated
- [ ] All tests pass
- [ ] No new warnings
- [ ] CHANGELOG.md is updated

## Questions?

Feel free to open an issue for:
- Bug reports
- Feature requests
- Questions about the code
- Documentation improvements

Thank you for contributing! 🚀
