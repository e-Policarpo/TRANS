#!/usr/bin/env python3
"""
Complete Main Window Fix Script
Adds ALL missing methods to main_window.py
"""

import sys
from pathlib import Path
import shutil
from datetime import datetime

def add_missing_methods(main_window_path: Path):
    """Add all missing methods to main_window.py"""
    
    # Create backup
    backup_path = main_window_path.with_suffix(f'.backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.py')
    shutil.copy(main_window_path, backup_path)
    print(f"✓ Backup created: {backup_path}")
    
    # Read current file
    with open(main_window_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Define all missing methods
    missing_methods = '''
    # ========================================================================
    # UI UPDATE METHODS (Added by complete fix script)
    # ========================================================================
    
    def update_ui_with_data(self):
        """Update UI after loading data."""
        if self.spectral_data is None:
            return
        
        # Update topography widget
        if self.topography_data:
            self.topography_widget.set_topography(self.topography_data)
        
        # Update data table
        self.update_data_table()
        
        # Update info
        self.update_info_display()
        
        # Update statistics
        self.update_statistics()
        
        # Update spectrum selector
        self.update_spectrum_selector()
        
        logger.info("UI updated with loaded data")
    
    def update_data_table(self):
        """Update data table with current spectral data."""
        if self.spectral_data is None:
            return
        
        try:
            df = self.spectral_data.data
            
            # Set up table dimensions
            max_rows = min(100, len(df))
            max_cols = min(20, len(df.columns))
            
            self.data_table.setRowCount(max_rows)
            self.data_table.setColumnCount(max_cols)
            
            # Set headers
            headers = [str(col) for col in df.columns[:max_cols]]
            self.data_table.setHorizontalHeaderLabels(headers)
            
            # Fill data
            for i in range(max_rows):
                for j in range(max_cols):
                    value = df.iloc[i, j]
                    item = QTableWidgetItem(f"{value:.6f}")
                    self.data_table.setItem(i, j, item)
            
            logger.debug(f"Data table updated: {max_rows}x{max_cols}")
            
        except Exception as e:
            logger.error(f"Error updating data table: {e}")
    
    def update_info_display(self):
        """Update information display with current data details."""
        if self.spectral_data is None:
            self.info_text.clear()
            return
        
        try:
            info = []
            
            # Spectral data info
            info.append("=== Spectral Data ===")
            info.append(f"Type: {self.spectral_data.metadata.source_type}")
            info.append(f"Dimensions: {self.spectral_data.metadata.dimensions}")
            info.append(f"Scan Mode: {self.spectral_data.metadata.scan_mode}")
            info.append(f"Spectra: {self.spectral_data.num_spectra}")
            info.append(f"Points/Spectrum: {self.spectral_data.num_points}")
            info.append("")
            
            # Units
            info.append("=== Units ===")
            for key, value in self.spectral_data.metadata.units.items():
                info.append(f"{key}: {value}")
            info.append("")
            
            # Topography info
            if self.topography_data:
                info.append("=== Topography ===")
                info.append(f"Shape: {self.topography_data.shape}")
                
                if self.topography_data.discretized_data is not None:
                    info.append(f"Discretized: {self.topography_data.discretized_data.shape}")
                    info.append(f"Block Size: {self.topography_data.block_size}")
                
                if self.topography_data.selected_blocks:
                    info.append(f"Selected Blocks: {len(self.topography_data.selected_blocks)}")
                info.append("")
            
            # Derivatives info
            if self.derivatives:
                info.append("=== Derivatives ===")
                for key in self.derivatives:
                    info.append(f"• {key}")
                info.append("")
            
            # Discretized data info
            if self.discretized_data:
                info.append("=== Discretized Data ===")
                for key, data in self.discretized_data.items():
                    info.append(f"• {key}: {data.num_spectra} blocks")
            
            self.info_text.setText("\n".join(info))
            
        except Exception as e:
            logger.error(f"Error updating info display: {e}")
    
    def update_spectrum_selector(self):
        """Update spectrum selection combo box."""
        if self.spectral_data is None:
            return
        
        try:
            self.spectrum_combo.clear()
            
            # Add spectrum column names (limit to first 100 for performance)
            spectrum_names = list(self.spectral_data.spectra.columns)[:100]
            self.spectrum_combo.addItems(spectrum_names)
            
            if spectrum_names:
                self.spectrum_combo.setCurrentIndex(0)
            
            logger.debug(f"Spectrum selector updated with {len(spectrum_names)} spectra")
            
        except Exception as e:
            logger.error(f"Error updating spectrum selector: {e}")
    
    def update_derivatives_display(self):
        """Update display after calculating derivatives."""
        if not self.derivatives:
            return
        
        try:
            info = ["", "=== Derivatives Calculated ==="]
            
            for key, deriv_data in self.derivatives.items():
                info.append(f"✓ {key}: {deriv_data.num_spectra} spectra, {deriv_data.num_points} points")
            
            # Append to info display
            current_text = self.info_text.toPlainText()
            self.info_text.setText(current_text + "\n" + "\n".join(info))
            
            # Scroll to bottom
            scrollbar = self.info_text.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())
            
            logger.info(f"Derivatives display updated with {len(self.derivatives)} derivative sets")
            
        except Exception as e:
            logger.error(f"Error updating derivatives display: {e}")
    
    def update_discretization_display(self):
        """Update display after discretization."""
        if not self.discretized_data:
            return
        
        try:
            info = ["", "=== Discretization Results ==="]
            
            for key, disc_data in self.discretized_data.items():
                info.append(f"✓ {key}: {disc_data.num_spectra} blocks")
            
            # Show discretization statistics if available
            if hasattr(self.discretizer, 'last_stats') and self.discretizer.last_stats:
                stats = self.discretizer.last_stats
                info.append("")
                info.append("Statistics:")
                info.append(f"  Grid: {stats.get('grid_shape', 'N/A')}")
                info.append(f"  Block size: {stats.get('block_size', 'N/A')}")
                info.append(f"  Total blocks: {stats.get('total_blocks', 'N/A')}")
                info.append(f"  Blocks used: {stats.get('blocks_used', 'N/A')}")
            
            # Append to info display
            current_text = self.info_text.toPlainText()
            self.info_text.setText(current_text + "\n" + "\n".join(info))
            
            # Scroll to bottom
            scrollbar = self.info_text.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())
            
            logger.info(f"Discretization display updated with {len(self.discretized_data)} datasets")
            
        except Exception as e:
            logger.error(f"Error updating discretization display: {e}")
    
    # ========================================================================
    # PROGRESS INDICATOR METHODS
    # ========================================================================
    
    def show_progress(self, message: str):
        """Show progress indicator with message."""
        try:
            self.progress_bar.show()
            self.progress_bar.setRange(0, 0)  # Indeterminate mode
            self.status_bar.showMessage(message)
            logger.debug(f"Progress shown: {message}")
        except Exception as e:
            logger.error(f"Error showing progress: {e}")
    
    def hide_progress(self):
        """Hide progress indicator."""
        try:
            self.progress_bar.hide()
            self.progress_bar.setRange(0, 100)  # Reset to determinate mode
            self.status_bar.clearMessage()
            logger.debug("Progress hidden")
        except Exception as e:
            logger.error(f"Error hiding progress: {e}")
    
    # ========================================================================
    # VIEW RESET METHOD
    # ========================================================================
    
    def reset_view(self):
        """Reset all views to default state."""
        try:
            # Reset topography widget
            if hasattr(self, 'topography_widget'):
                self.topography_widget.reset_view()
            
            # Reset tab to first tab
            if hasattr(self, 'tabs'):
                self.tabs.setCurrentIndex(0)
            
            # Clear selection
            if self.topography_data:
                self.topography_data.selected_blocks = []
            
            # Reset data table scroll
            if hasattr(self, 'data_table'):
                self.data_table.scrollToTop()
            
            # Clear progress
            self.hide_progress()
            
            # Clear status
            self.status_bar.showMessage("View reset", 2000)
            
            logger.info("View reset to default state")
            
        except Exception as e:
            logger.error(f"Error resetting view: {e}")
            QMessageBox.warning(self, "Warning", f"Error resetting view: {str(e)}")
'''
    
    # Find insertion point (before show_about or at end of class)
    # Look for the last method definition in the class
    lines = content.split('\n')
    
    # Find the last line of the class (before any trailing code)
    insert_index = -1
    for i in range(len(lines) - 1, -1, -1):
        # Look for show_about method
        if 'def show_about' in lines[i]:
            insert_index = i
            break
    
    # If show_about not found, insert before the last few lines
    if insert_index == -1:
        # Find last method definition
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].strip().startswith('def ') and not lines[i].strip().startswith('def __'):
                # Find end of this method
                for j in range(i + 1, len(lines)):
                    # Next method or class end
                    if lines[j].strip() and not lines[j].startswith(' ') and not lines[j].startswith('\t'):
                        insert_index = j
                        break
                    elif j < len(lines) - 1 and lines[j+1].strip().startswith('def '):
                        insert_index = j + 1
                        break
                if insert_index != -1:
                    break
        
        # Fallback: insert near end
        if insert_index == -1:
            insert_index = len(lines) - 10
    
    # Insert the methods
    new_content = '\n'.join(lines[:insert_index]) + missing_methods + '\n' + '\n'.join(lines[insert_index:])
    
    # Write back
    with open(main_window_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    print(f"✓ Added missing methods to {main_window_path}")
    print("\nMethods added:")
    print("  • update_ui_with_data")
    print("  • update_data_table")
    print("  • update_info_display")
    print("  • update_spectrum_selector")
    print("  • update_derivatives_display")
    print("  • update_discretization_display")
    print("  • show_progress")
    print("  • hide_progress")
    print("  • reset_view")
    print("")
    print("✅ Main window is now complete!")

def main():
    """Main function."""
    # Find main_window.py
    possible_paths = [
        Path('src/ui/main_window.py'),
        Path('../src/ui/main_window.py'),
        Path('../../src/ui/main_window.py'),
    ]
    
    main_window_path = None
    for path in possible_paths:
        if path.exists():
            main_window_path = path
            break
    
    if main_window_path is None:
        print("❌ Error: Could not find src/ui/main_window.py")
        print("   Make sure you're running this from the project root")
        sys.exit(1)
    
    print(f"Found: {main_window_path}")
    print("")
    
    # Add missing methods
    add_missing_methods(main_window_path)
    
    print("\n" + "="*60)
    print("Next steps:")
    print("  1. Test syntax: python3 -m py_compile src/ui/main_window.py")
    print("  2. Run application: python3 main.py")
    print("  3. Test features (load data, calculate derivatives, etc.)")
    print("="*60)

if __name__ == '__main__':
    main()
