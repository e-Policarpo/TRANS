#!/bin/bash

################################################################################
# Fix Main Window Missing Methods
# Adds missing methods to main_window.py
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

PROJECT_ROOT="${PROJECT_ROOT:-$(pwd)}"
MAIN_WINDOW="${PROJECT_ROOT}/src/ui/main_window.py"

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Fixing Main Window Missing Methods${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

if [ ! -f "$MAIN_WINDOW" ]; then
    echo -e "${RED}✗${NC} File not found: $MAIN_WINDOW"
    exit 1
fi

# Create backup
BACKUP="${MAIN_WINDOW}.backup_$(date +%Y%m%d_%H%M%S)"
cp "$MAIN_WINDOW" "$BACKUP"
echo -e "${GREEN}✓${NC} Created backup: $BACKUP"

# Create the missing methods file
cat > /tmp/missing_methods.py << 'EOFMETHODS'
    
    # ========================================================================
    # DATA LOADING METHODS (Added by fix script)
    # ========================================================================
    
    def load_from_directory(self):
        """Load data from directory of measurement files."""
        try:
            directory = QFileDialog.getExistingDirectory(
                self,
                "Select Data Directory",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not directory:
                return
            
            directory = Path(directory)
            
            # Determine data type
            loader_type, _ = QInputDialog.getItem(
                self,
                "Select Data Type",
                "Choose the type of data to load:",
                ["Nanosurf STS (.nid)", "NeaSpec SNOM (.txt)"],
                0,
                False
            )
            
            if not loader_type:
                return
            
            # Select appropriate loader
            if "Nanosurf" in loader_type:
                loader = self.loaders['nanosurf']
            else:
                loader = self.loaders['neaspec']
            
            # Load data with progress
            self.log_message(f"Loading data from {directory}...")
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            # Load
            spectral_data, topography = loader.load_from_directory(directory)
            
            self.spectral_data = spectral_data
            self.topography_data = topography
            
            # Detect data type
            if hasattr(spectral_data.metadata, 'additional_info'):
                self.current_data_type = spectral_data.metadata.additional_info.get('data_type', 'iv')
            else:
                self.current_data_type = 'iv'
            
            # Update UI
            self.progress_bar.setValue(100)
            self.update_statistics()
            
            if topography:
                self.topography_widget.set_topography(topography)
            
            self.log_message(f"✓ Loaded {spectral_data.num_spectra} spectra")
            self.log_message(f"✓ Data type detected: {self.current_data_type}")
            
            QMessageBox.information(
                self,
                "Success",
                f"Loaded {spectral_data.num_spectra} spectra from {directory.name}"
            )
            
        except Exception as e:
            logger.error(f"Error loading directory: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load data:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    def load_single_file(self):
        """Load data from single file."""
        try:
            filepath, _ = QFileDialog.getOpenFileName(
                self,
                "Select Data File",
                "",
                "All Supported (*.nid *.txt *.csv);;Nanosurf (*.nid);;NeaSpec (*.txt);;CSV (*.csv)"
            )
            
            if not filepath:
                return
            
            filepath = Path(filepath)
            
            # Determine loader by extension
            if filepath.suffix == '.nid':
                loader = self.loaders['nanosurf']
            elif filepath.suffix in ['.txt', '.dat']:
                loader = self.loaders['neaspec']
            elif filepath.suffix == '.csv':
                self.load_csv_file(filepath)
                return
            else:
                QMessageBox.warning(self, "Warning", f"Unsupported file type: {filepath.suffix}")
                return
            
            # Load
            self.log_message(f"Loading {filepath.name}...")
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            
            spectral_data = loader.load_single_file(filepath)
            self.spectral_data = spectral_data
            
            # Detect data type
            self.current_data_type = BaseDataLoader.detect_data_type(filepath)
            
            self.progress_bar.setValue(100)
            self.update_statistics()
            
            self.log_message(f"✓ Loaded {spectral_data.num_spectra} spectra")
            self.log_message(f"✓ Data type: {self.current_data_type}")
            
            QMessageBox.information(
                self,
                "Success",
                f"Loaded {spectral_data.num_spectra} spectra"
            )
            
        except Exception as e:
            logger.error(f"Error loading file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load file:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    def load_csv_file(self, filepath: Path):
        """Load spectral data from CSV file."""
        try:
            df = pd.read_csv(filepath)
            
            # Guess dimensions
            n_spectra = len(df.columns) - 1
            dim_h = int(np.sqrt(n_spectra))
            dim_v = n_spectra // dim_h
            
            metadata = SpectralMetadata(
                source_type='csv',
                dimensions=(dim_h, dim_v),
                scan_mode='unknown',
                units={'independent': 'V', 'dependent': 'A'}
            )
            
            self.spectral_data = SpectralData(df, metadata)
            
            # Detect data type from filename
            self.current_data_type = BaseDataLoader.detect_data_type(filepath)
            
            self.update_statistics()
            self.log_message(f"✓ Loaded CSV: {n_spectra} spectra")
            
        except Exception as e:
            raise ValueError(f"Error loading CSV: {e}")
    
    # ========================================================================
    # EXPORT METHODS
    # ========================================================================
    
    def export_to_csv(self):
        """Export current spectral data to CSV."""
        try:
            if self.spectral_data is None:
                QMessageBox.warning(self, "Warning", "No data to export")
                return
            
            filepath, _ = QFileDialog.getSaveFileName(
                self,
                "Export to CSV",
                "",
                "CSV Files (*.csv)"
            )
            
            if not filepath:
                return
            
            # Export
            self.spectral_data.save(filepath)
            
            # If discretized, also export that
            if self.discretized_data:
                base = Path(filepath).stem
                parent = Path(filepath).parent
                
                for key, data in self.discretized_data.items():
                    discretized_path = parent / f"{base}_{key}.csv"
                    data.save(discretized_path)
                
                msg = f"Exported:\n{filepath}\n{discretized_path}"
            else:
                msg = f"Exported:\n{filepath}"
            
            self.log_message(f"✓ {msg}")
            QMessageBox.information(self, "Success", msg)
            
        except Exception as e:
            logger.error(f"Error exporting: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to export:\n{str(e)}")
    
    def export_selection(self):
        """Export only selected blocks."""
        try:
            if self.topography_data is None:
                QMessageBox.warning(self, "Warning", "No topography data")
                return
            
            if not self.topography_data.selected_blocks:
                QMessageBox.warning(self, "Warning", "No blocks selected")
                return
            
            filepath, _ = QFileDialog.getSaveFileName(
                self,
                "Export Selection",
                "",
                "CSV Files (*.csv)"
            )
            
            if not filepath:
                return
            
            # Create mask from selection
            mask = self.topography_data.get_selection_mask()
            
            # Apply mask to current data
            if self.spectral_data:
                masked_data = self.spectral_data.apply_mask(mask)
                masked_data.save(filepath)
                self.log_message(f"✓ Exported {len(self.topography_data.selected_blocks)} blocks")
            
            QMessageBox.information(
                self,
                "Success",
                f"Exported {len(self.topography_data.selected_blocks)} selected blocks"
            )
            
        except Exception as e:
            logger.error(f"Error exporting selection: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to export:\n{str(e)}")
    
    def generate_maps(self):
        """Generate spatial maps from integrated data."""
        try:
            if self.spectral_data is None:
                QMessageBox.warning(self, "Warning", "No spectral data loaded")
                return
            
            # Show map configuration dialog
            dialog = MapDialog(self)
            if dialog.exec() != QDialog.Accepted:
                return
            
            intervals = dialog.get_intervals()
            if not intervals:
                QMessageBox.warning(self, "Warning", "No integration intervals defined")
                return
            
            # Select output directory
            output_dir = QFileDialog.getExistingDirectory(
                self,
                "Select Output Directory for Maps",
                "",
                QFileDialog.ShowDirsOnly
            )
            
            if not output_dir:
                return
            
            output_dir = Path(output_dir)
            
            # Set intervals and generate maps
            self.map_generator.set_integration_intervals(intervals)
            
            self.log_message(f"Generating maps for {len(intervals)} intervals...")
            self.progress_bar.setVisible(True)
            
            maps = self.map_generator.generate_maps_for_dataset(
                self.spectral_data,
                output_dir,
                self.current_data_type
            )
            
            self.progress_bar.setValue(100)
            self.log_message(f"✓ Generated {len(maps)} maps")
            
            QMessageBox.information(
                self,
                "Success",
                f"Generated {len(maps)} maps in {output_dir}"
            )
            
        except Exception as e:
            logger.error(f"Error generating maps: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to generate maps:\n{str(e)}")
        finally:
            self.progress_bar.setVisible(False)
    
    # ========================================================================
    # UI CALLBACK METHODS
    # ========================================================================
    
    def on_selection_changed(self):
        """Handle topography selection changes."""
        if self.topography_data:
            n_selected = len(self.topography_data.selected_blocks)
            self.log_message(f"Selection: {n_selected} blocks selected")
            self.update_statistics()
    
    def log_message(self, message: str):
        """Add message to processing log."""
        if hasattr(self, 'log_text'):
            self.log_text.append(message)
            # Auto-scroll to bottom
            scrollbar = self.log_text.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())
EOFMETHODS

# Find where to insert (before the last method or before the show_about method)
LINE_NUM=$(grep -n "def show_about" "$MAIN_WINDOW" | cut -d: -f1)

if [ -z "$LINE_NUM" ]; then
    # If show_about doesn't exist, insert before last line
    LINE_NUM=$(wc -l < "$MAIN_WINDOW")
fi

# Insert the methods
head -n $((LINE_NUM - 1)) "$MAIN_WINDOW" > "${MAIN_WINDOW}.tmp"
cat /tmp/missing_methods.py >> "${MAIN_WINDOW}.tmp"
tail -n +$LINE_NUM "$MAIN_WINDOW" >> "${MAIN_WINDOW}.tmp"

# Replace original
mv "${MAIN_WINDOW}.tmp" "$MAIN_WINDOW"

echo -e "${GREEN}✓${NC} Added missing methods to main_window.py"
echo ""
echo "Added methods:"
echo "  • load_from_directory"
echo "  • load_single_file"
echo "  • load_csv_file"
echo "  • export_to_csv"
echo "  • export_selection"
echo "  • generate_maps"
echo "  • on_selection_changed"
echo "  • log_message"
echo ""
echo -e "${GREEN}✅ Main window fixed!${NC}"
echo ""
echo "Backup saved at: $BACKUP"