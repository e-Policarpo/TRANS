# 🚀 Quick Start - Aplicar Fixes v0.5.0

## TL;DR - Execução Rápida

```bash
# 1. Dê permissões
chmod +x apply_fixes.sh verify_fixes.sh

# 2. Execute os fixes
./apply_fixes.sh

# 3. Verifique
./verify_fixes.sh

# 4. Teste
python main.py
```

## 📦 O Que Você Receberá

Após executar `apply_fixes.sh`, você terá:

### ✅ Correções Automáticas
- **Encoding UTF-8** - Todos os caracteres especiais (², µ, Ç) corrigidos
- **BaseDataLoader** - Código consolidado e otimizado
- **4 arquivos Python** corrigidos automaticamente

### 📁 Arquivos Novos
```
scripts/fix_encoding.py      ← Script utilitário para encodings
tests/test_spectral_data.py  ← Testes unitários
CHANGELOG.md                  ← Histórico de versões
CONTRIBUTING.md               ← Guia de contribuição
```

### 📝 Arquivos Atualizados
```
requirements.txt              ← Dependências organizadas
src/data_loaders/base_loader.py ← Código consolidado
```

### 💾 Backup Automático
```
backup_YYYYMMDD_HHMMSS/       ← Todos os arquivos originais salvos
```

## 🎯 Ordem de Execução

### Passo 1: Preparação (1 minuto)
```bash
cd /path/to/hyperspec_analyzer
chmod +x apply_fixes.sh verify_fixes.sh
```

### Passo 2: Aplicar Fixes (2-3 minutos)
```bash
./apply_fixes.sh
```

**Você verá:**
```
════════════════════════════════════════════════════════════════
  HyperSpec Analyzer - Applying Fixes v0.5.0
════════════════════════════════════════════════════════════════

✓ Created backup directory: backup_20250121_143052
✓ Backed up: derivatives.py
✓ Fixed encoding: derivatives.py
...
✅ All fixes applied successfully!
```

### Passo 3: Verificar (1 minuto)
```bash
./verify_fixes.sh
```

**Você verá:**
```
════════════════════════════════════════════════════════════════
  HyperSpec Analyzer - Verify Fixes v0.5.0
════════════════════════════════════════════════════════════════

✓ src/ directory exists
✓ fix_encoding.py script created
✓ derivatives.py encoding fixed
...
✅ All checks passed!
```

### Passo 4: Testar (Opcional, 5 minutos)
```bash
# Ativar ambiente virtual
source venv/bin/activate

# Executar testes
python -m pytest tests/ -v

# Testar aplicação
python main.py
```

### Passo 5: Commit (1 minuto)
```bash
git status
git add .
git commit -m "feat: apply v0.5.0 fixes - encoding, tests, docs"
```

## 📊 Checklist Rápido

- [ ] Executei `apply_fixes.sh` sem erros
- [ ] Backup foi criado
- [ ] `verify_fixes.sh` passou todos os checks
- [ ] Testes executam (`pytest tests/`)
- [ ] Aplicação inicia (`python main.py`)
- [ ] Fiz commit das mudanças

## 🔴 Se Algo Der Errado

### Erro: "Permission denied"
```bash
chmod +x apply_fixes.sh verify_fixes.sh
```

### Erro: Encoding ainda incorreto
```bash
python scripts/fix_encoding.py
```

### Erro: Arquivos não encontrados
```bash
# Certifique-se de estar na raiz do projeto
pwd  # Deve mostrar .../hyperspec_analyzer
ls -la  # Deve mostrar src/, main.py, etc.
```

### Reverter tudo
```bash
# Encontre o backup
ls -la | grep backup_

# Restaure os arquivos
cp -r backup_20250121_143052/* .

# Ou use git
git checkout -- .
```

## ⏱️ Tempo Estimado Total

- **Execução automática**: 5-10 minutos
- **Testes manuais**: +5 minutos (opcional)
- **Revisão de código**: +15 minutos (recomendado)

**Total**: 10-30 minutos dependendo da profundidade da verificação

## 📚 Documentação Completa

Para mais detalhes, consulte:

- 📖 `INSTRUCOES_FIXES.md` - Guia completo passo a passo
- 📖 `code_analysis.md` - Análise detalhada do código
- 📖 `quick_fixes.md` - Detalhes de cada correção
- 📖 `CHANGELOG.md` - O que mudou em cada versão

## 💡 Dicas

1. **Sempre revise** com `git diff` antes de fazer commit
2. **Execute os testes** antes de considerar completo
3. **Teste a aplicação** para garantir que funciona
4. **Mantenha os backups** por alguns dias antes de deletar

## 🎉 Parabéns!

Após completar estes passos, seu código estará:
- ✅ Sem problemas de encoding
- ✅ Com código consolidado
- ✅ Com testes unitários configurados
- ✅ Com documentação atualizada
- ✅ Pronto para desenvolvimento da v0.6.0

---

**Versão**: 0.5.0  
**Autor**: Eduarda Policarpo 🏳️‍⚧️  
**Data**: Janeiro 2025

**Precisa de ajuda?** Abra uma issue ou consulte `INSTRUCOES_FIXES.md`
