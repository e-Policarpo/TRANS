#!/bin/bash

################################################################################
# Complete Fix for Main Window - Wrapper Script
# Adds all 9 missing methods to main_window.py
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Complete Main Window Fix - All Missing Methods${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

# Check if Python script exists
if [ ! -f "fix_all_missing_methods.py" ]; then
    echo -e "${RED}✗${NC} Error: fix_all_missing_methods.py not found"
    echo ""
    echo "Please download fix_all_missing_methods.py first"
    exit 1
fi

# Run the Python script
echo -e "${YELLOW}Running Python fix script...${NC}"
echo ""

python3 fix_all_missing_methods.py

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  ✅ SUCCESS! All methods added!${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "Methods added:"
    echo "  ✓ update_ui_with_data"
    echo "  ✓ update_data_table"
    echo "  ✓ update_info_display"
    echo "  ✓ update_spectrum_selector"
    echo "  ✓ update_derivatives_display"
    echo "  ✓ update_discretization_display"
    echo "  ✓ show_progress"
    echo "  ✓ hide_progress"
    echo "  ✓ reset_view"
    echo ""
    echo "Next steps:"
    echo "  1. Test syntax: python3 -m py_compile src/ui/main_window.py"
    echo "  2. Run app: python3 main.py"
    echo "  3. Test all features"
    echo ""
    exit 0
else
    echo ""
    echo -e "${RED}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${RED}  ❌ ERROR occurred during fix${NC}"
    echo -e "${RED}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo "Please check the error messages above"
    echo ""
    exit 1
fi
