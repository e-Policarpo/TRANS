# Changelog

All notable changes to the HyperSpec Analyzer project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2025-01-XX

### Fixed
- ✅ UTF-8 encoding issues in multiple files (d², µ, Ç, Ã)
- ✅ Hard-coded macOS paths replaced with relative paths
- ✅ Consolidated data type detection in BaseDataLoader
- ✅ Removed duplicate code from main_window.py

### Added
- ✨ Polynomial baseline correction UI for derivatives
- ✨ I-V smoothing parameters controls (window_length, polyorder)
- ✨ Discretization statistics display
- ✨ Basic spectrum visualization with matplotlib
- ✨ Topography CSV export functionality
- 📝 Unit test template for SpectralData
- 📝 Fix encoding utility script
- 📝 CHANGELOG.md file
- 📝 Enhanced README documentation

### Changed
- 🔄 Refactored BaseDataLoader for better maintainability
- 🔄 Improved error handling and logging
- 🔄 Updated requirements.txt with optional dependencies

### Technical Improvements
- 🏗️ Better separation of concerns (still needs more work)
- 🧪 Test infrastructure setup
- 📊 More detailed logging throughout
- ✅ Input validation improvements

## [0.4.0] - Previous Version

### Added
- Initial modular architecture
- PySide6 GUI implementation
- SpectralData and TopographyData models
- Nanosurf STS and NeaSpec SNOM loaders
- Derivatives calculation
- Discretization with block selection
- Map generation

### Fixed
- Edge block handling in discretization
- Meander correction algorithm

## [0.3.0] - TRANS_v3.py (Legacy)

Original implementation with Tkinter GUI.

---

## Legend

- ✅ Fixed bug
- ✨ New feature
- 🔄 Changed existing feature
- 📝 Documentation
- 🏗️ Architecture/refactoring
- 🧪 Testing
- 📊 Logging/monitoring
- ⚠️ Deprecated
- 🗑️ Removed
