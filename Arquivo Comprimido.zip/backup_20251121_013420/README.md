# HyperSpec Analyzer

Sistema avançado para análise de dados hiperespectrais, reimplementado com arquitetura modular e boas práticas.

## 🚀 Melhorias Implementadas

### Arquitetura e Código
- ✅ **Modularização completa** - Código separado em módulos lógicos
- ✅ **PySide6 GUI** - Interface moderna substituindo Tkinter
- ✅ **Correção do bug de blocos** - Tratamento correto de bordas na discretização
- ✅ **Nomes descritivos** - Classes, métodos e variáveis com nomenclatura clara
- ✅ **Eliminação de magic numbers** - Constantes bem definidas
- ✅ **Documentação completa** - Docstrings em todos os módulos

### Estrutura de Dados
- ✅ **SpectralData** - Classe unificada para dados espectrais
- ✅ **TopographyData** - Gerenciamento dedicado de topografia
- ✅ **Correção de meandro** - Implementada corretamente
- ✅ **Sistema extensível** - Fácil adicionar novos tipos de dados

### Loaders Implementados
1. **NanosurfSTSLoader** - Para arquivos .nid com patch automático para STM
2. **NeaSpecSNOMLoader** - Para arquivos .txt de SNOM

## 📁 Estrutura do Projeto

```
hyperspec_analyzer/
├── main.py                 # Ponto de entrada principal
├── requirements.txt        # Dependências Python
├── setup.sh               # Script de instalação automática
├── README.md              # Este arquivo
└── src/
    ├── __init__.py
    ├── models/            # Modelos de dados
    │   ├── __init__.py
    │   ├── spectral_data.py
    │   └── topography_data.py
    ├── data_loaders/      # Carregadores de dados
    │   ├── __init__.py
    │   ├── base_loader.py
    │   ├── nanosurf_sts_loader.py
    │   └── neaspec_snom_loader.py
    ├── processing/        # Processamento de dados
    │   ├── __init__.py
    │   ├── derivatives.py
    │   └── discretization.py
    └── ui/               # Interface gráfica
        ├── __init__.py
        ├── main_window.py
        └── topography_widget.py
```

## 🔧 Instalação

### Método Automático (Recomendado)

```bash
# Tornar o script executável
chmod +x setup.sh

# Executar instalação
./setup.sh
```

### Método Manual

```bash
# Criar ambiente virtual
python3 -m venv venv

# Ativar ambiente
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instalar dependências
pip install -r requirements.txt
```

## 🎮 Uso

### Executar a aplicação

```bash
# Com ambiente ativado
python main.py
```

### Workflow típico

1. **Carregar Dados**
   - Selecione o tipo de dados (Nanosurf STS ou NeaSpec SNOM)
   - Clique em "Load from Directory" ou "Load Single File"

2. **Pré-processamento**
   - Ajuste o intervalo de truncamento (V min/max)
   - Ative/desative suavização
   - Clique em "Truncate Range"

3. **Calcular Derivadas**
   - Selecione quais derivadas calcular
   - Escolha se deseja correção polinomial
   - Clique em "Calculate Derivatives"

4. **Discretização**
   - Configure tamanho dos blocos (Block H/V)
   - Selecione blocos interativamente na topografia
   - Clique em "Apply Discretization"

5. **Exportar Resultados**
   - Clique em "Export to CSV"
   - Escolha qual conjunto de dados exportar

## 🐛 Correções de Bugs

### Bug de Blocos nas Bordas (CORRIGIDO)
O código original tinha um problema ao processar blocos nas bordas da matriz. A nova implementação:
- Usa `math.ceil()` para calcular número de grupos
- Trata corretamente blocos parciais nas bordas
- Valida índices antes de acessar arrays

### Patch NSFopen para STM
O loader Nanosurf aplica automaticamente patches para ignorar metadados de cantilever ausentes em dados STM:
- Remove referências a 'cantilever'
- Comenta linhas problemáticas (212-228)
- Funciona sem modificar a biblioteca instalada

## 🔄 Fluxo de Dados

```
Arquivos .nid/.txt
        ↓
   DataLoader
        ↓
  SpectralData
        ↓
   [Correção Meandro]
        ↓
   [Truncamento]
        ↓
   [Derivadas]
        ↓
   [Discretização]
        ↓
   Exportação CSV
```

## 📊 Principais Classes

### SpectralData
- Armazena dados espectrais em DataFrame padronizado
- Primeira coluna: variável independente
- Colunas seguintes: espectros de diferentes posições
- Suporta correção de meandro, truncamento, máscaras

### TopographyData
- Gerencia dados de topografia/altura
- Suporta discretização em blocos
- Seleção interativa de blocos
- Exportação como imagem

### DerivativesProcessor
- Calcula 1ª e 2ª derivadas
- Aplica suavização Savitzky-Golay
- Correção de baseline polinomial

### Discretizer
- Discretiza dados em blocos espaciais
- Tratamento correto de bordas
- Suporta seleção de blocos específicos
- Gera dados intermediários e finais

## 🎯 Funcionalidades Principais

- ✅ Carregamento de múltiplos formatos
- ✅ Correção automática de meandro
- ✅ Cálculo de derivadas com suavização
- ✅ Discretização espacial com seleção interativa
- ✅ Correção polinomial de baseline
- ✅ Exportação para CSV
- ✅ Interface gráfica moderna com PySide6
- ✅ Visualização de topografia
- ✅ Log de processamento em tempo real

## 📝 Notas Importantes

1. **Compatibilidade com dados legados**: O novo sistema lê os mesmos arquivos mas com estrutura interna melhorada

2. **Performance**: Otimizado para conjuntos de dados grandes (dezenas de milhares de arquivos)

3. **Extensibilidade**: Fácil adicionar novos tipos de dados criando novos loaders

4. **Manutenibilidade**: Código limpo, documentado e testável

## 🆘 Solução de Problemas

### NSFopen não encontrado
```bash
pip install NSFopen
```

### Erro de importação PySide6
```bash
pip install PySide6
```

### Dados não carregando
- Verifique se os arquivos estão no formato correto
- Confirme que o diretório contém arquivos .nid ou .txt
- Veja o log de erros na interface

## 🔮 Próximas Melhorias

- [ ] Adicionar mais tipos de visualização
- [ ] Implementar geração de mapas coloridos
- [ ] Suporte para mais formatos de arquivo
- [ ] Análise estatística avançada
- [ ] Exportação para HDF5

## 📄 Licença

Código reimplementado com melhorias significativas.
Mantém compatibilidade com workflows existentes.
