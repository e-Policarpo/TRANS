"""
Unit tests for SpectralData model
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from models.spectral_data import SpectralData, SpectralMetadata


class TestSpectralData:
    """Test suite for SpectralData class."""
    
    @pytest.fixture
    def sample_metadata(self):
        """Create sample metadata for testing."""
        return SpectralMetadata(
            source_type='test',
            dimensions=(10, 10),
            scan_mode='meander',
            units={'independent': 'V', 'dependent': 'A'}
        )
    
    @pytest.fixture
    def sample_data(self):
        """Create sample spectral data DataFrame."""
        V = np.linspace(-1, 1, 100)
        data = {'V': V}
        
        # Add 100 spectra
        for i in range(100):
            data[f'Spectrum_{i+1}'] = np.sin(2 * np.pi * V + i * 0.1)
        
        return pd.DataFrame(data)
    
    def test_spectral_data_creation(self, sample_data, sample_metadata):
        """Test creating SpectralData object."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        assert spectral is not None
        assert spectral.num_spectra == 100
        assert spectral.num_points == 100
        assert spectral.independent_var_name == 'V'
    
    def test_meander_correction(self, sample_data, sample_metadata):
        """Test meander scan correction."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        # Should not be corrected yet
        assert not spectral._corrected_meander
        
        # Apply correction
        spectral.correct_meander()
        
        # Should be corrected now
        assert spectral._corrected_meander
    
    def test_to_3d_cube(self, sample_data, sample_metadata):
        """Test conversion to 3D cube."""
        spectral = SpectralData(sample_data, sample_metadata)
        cube = spectral.to_3d_cube()
        
        assert cube.shape == (100, 10, 10)
        assert cube.dtype == np.float64
    
    def test_truncate_range(self, sample_data, sample_metadata):
        """Test range truncation."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        truncated = spectral.truncate_range(-0.5, 0.5)
        
        assert truncated.num_points < spectral.num_points
        assert truncated.independent_var.min() >= -0.5
        assert truncated.independent_var.max() <= 0.5
    
    def test_invalid_data(self, sample_metadata):
        """Test validation of invalid data."""
        # Should raise error for non-DataFrame
        with pytest.raises(TypeError):
            SpectralData(np.array([1, 2, 3]), sample_metadata)
        
        # Should raise error for < 2 columns
        df_invalid = pd.DataFrame({'V': [1, 2, 3]})
        with pytest.raises(ValueError):
            SpectralData(df_invalid, sample_metadata)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
