"""
Unit tests for HyperSpec Analyzer
"""
