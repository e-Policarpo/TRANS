#!/bin/bash

################################################################################
# HyperSpec Analyzer - Apply Fixes Script
# Version: 0.5.0
# 
# This script applies all corrections described in code_analysis.md and 
# quick_fixes.md to the HyperSpec Analyzer project.
#
# Usage: ./apply_fixes.sh
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get script directory and project root
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="${PROJECT_ROOT:-$(pwd)}"

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  HyperSpec Analyzer - Applying Fixes v0.5.0${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${YELLOW}Project root: ${PROJECT_ROOT}${NC}"
echo ""

# Create backup directory
BACKUP_DIR="${PROJECT_ROOT}/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
echo -e "${GREEN}✓${NC} Created backup directory: ${BACKUP_DIR}"

################################################################################
# Function: backup_file
# Backs up a file before modifying it
################################################################################
backup_file() {
    local file="$1"
    if [ -f "$file" ]; then
        local backup_path="${BACKUP_DIR}/$(basename "$file")"
        cp "$file" "$backup_path"
        echo -e "${GREEN}  ✓${NC} Backed up: $(basename "$file")"
        return 0
    else
        echo -e "${YELLOW}  ⚠${NC} File not found: $file"
        return 1
    fi
}

################################################################################
# Function: fix_encoding
# Fixes UTF-8 encoding issues in a file
################################################################################
fix_encoding() {
    local file="$1"
    local temp_file="${file}.tmp"
    
    if [ ! -f "$file" ]; then
        echo -e "${YELLOW}  ⚠${NC} File not found: $file"
        return 1
    fi
    
    # Apply encoding fixes using sed
    # Note: Using perl for better UTF-8 handling
    perl -i.bak -pe 's/Â²/²/g; s/µ/µ/g; s/Ç/Ç/g; s/Ã/Ã/g' "$file"
    
    # Remove backup created by perl
    rm -f "${file}.bak"
    
    echo -e "${GREEN}  ✓${NC} Fixed encoding: $(basename "$file")"
    return 0
}

################################################################################
# STEP 1: Fix Encoding Issues
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 1: Fixing Encoding Issues${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

# List of files to fix encoding
FILES_TO_FIX=(
    "src/processing/derivatives.py"
    "src/processing/map_generator.py"
    "src/data_loaders/neaspec_snom_loader.py"
    "src/processing/iv_processor.py"
)

for file in "${FILES_TO_FIX[@]}"; do
    file_path="${PROJECT_ROOT}/${file}"
    if backup_file "$file_path"; then
        fix_encoding "$file_path"
    fi
done

################################################################################
# STEP 2: Fix BaseDataLoader - Consolidate Data Type Detection
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 2: Fixing BaseDataLoader${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

BASE_LOADER="${PROJECT_ROOT}/src/data_loaders/base_loader.py"
if backup_file "$BASE_LOADER"; then
    # Create corrected version
    cat > "${BASE_LOADER}.new" << 'EOFBASELOADER'
"""
Base Data Loader
Abstract base class for all data loaders
"""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path
import logging
import pandas as pd
import numpy as np

from ..models.spectral_data import SpectralData, SpectralMetadata
from ..models.topography_data import TopographyData, TopographyMetadata

logger = logging.getLogger(__name__)


class BaseDataLoader(ABC):
    """
    Abstract base class for hyperspectral data loaders.
    
    Each specific loader must implement the load_from_directory method
    to handle its specific file format and data structure.
    """
    
    def __init__(self):
        """Initialize base loader"""
        self.supported_extensions: List[str] = []
        self.loader_type: str = "base"
        self.last_loaded_path: Optional[Path] = None
        
    @abstractmethod
    def load_from_directory(self, directory: Path) -> Tuple[SpectralData, Optional[TopographyData]]:
        """
        Load data from a directory containing measurement files.
        
        Parameters:
        -----------
        directory : Path
            Directory containing data files
            
        Returns:
        --------
        spectral_data : SpectralData
            Loaded and processed spectral data
        topography : TopographyData or None
            Associated topography data if available
        """
        pass
    
    @abstractmethod
    def load_single_file(self, filepath: Path) -> SpectralData:
        """
        Load data from a single file.
        
        Parameters:
        -----------
        filepath : Path
            Path to data file
            
        Returns:
        --------
        spectral_data : SpectralData
            Loaded spectral data
        """
        pass
    
    def validate_directory(self, directory: Path) -> bool:
        """
        Validate that directory exists and contains supported files.
        
        Parameters:
        -----------
        directory : Path
            Directory to validate
            
        Returns:
        --------
        valid : bool
            True if directory is valid
        """
        if not directory.exists():
            logger.error(f"Directory does not exist: {directory}")
            return False
        
        if not directory.is_dir():
            logger.error(f"Path is not a directory: {directory}")
            return False
        
        # Check for supported files
        has_files = False
        for ext in self.supported_extensions:
            if list(directory.glob(f"*{ext}")):
                has_files = True
                break
        
        if not has_files:
            logger.warning(f"No supported files ({self.supported_extensions}) found in {directory}")
            return False
        
        return True
    
    def find_files(self, directory: Path, pattern: str = "*") -> List[Path]:
        """
        Find files matching pattern in directory.
        
        Parameters:
        -----------
        directory : Path
            Directory to search
        pattern : str
            Glob pattern for files
            
        Returns:
        --------
        files : List[Path]
            Sorted list of matching files
        """
        files = []
        for ext in self.supported_extensions:
            files.extend(directory.glob(f"{pattern}{ext}"))
        
        # Sort files for consistent ordering
        files = sorted(files, key=lambda x: x.name)
        
        logger.info(f"Found {len(files)} files matching pattern '{pattern}' in {directory}")
        return files
    
    def create_metadata(self, 
                       dimensions: Tuple[int, int],
                       scan_mode: str = "meander",
                       units: Optional[Dict[str, str]] = None,
                       **kwargs) -> SpectralMetadata:
        """
        Create metadata object with common parameters.
        
        Parameters:
        -----------
        dimensions : Tuple[int, int]
            (horizontal, vertical) dimensions
        scan_mode : str
            Scanning mode
        units : Dict[str, str]
            Units dictionary
        **kwargs : Any
            Additional metadata fields
            
        Returns:
        --------
        metadata : SpectralMetadata
            Metadata object
        """
        if units is None:
            units = {}
        
        return SpectralMetadata(
            source_type=self.loader_type,
            dimensions=dimensions,
            scan_mode=scan_mode,
            units=units,
            additional_info=kwargs
        )
    
    def concatenate_spectra(self, 
                           spectra_list: List[np.ndarray],
                           independent_var: np.ndarray,
                           column_names: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Concatenate multiple spectra into a DataFrame.
        
        Parameters:
        -----------
        spectra_list : List[np.ndarray]
            List of 1D spectra arrays
        independent_var : np.ndarray
            Independent variable (e.g., voltage, wavenumber)
        column_names : List[str], optional
            Names for spectrum columns
            
        Returns:
        --------
        df : pd.DataFrame
            DataFrame with concatenated spectra
        """
        # Stack spectra
        if len(spectra_list) == 0:
            raise ValueError("No spectra to concatenate")
        
        # Ensure all spectra have same length
        spec_len = len(spectra_list[0])
        for i, spec in enumerate(spectra_list):
            if len(spec) != spec_len:
                logger.warning(f"Spectrum {i} has different length ({len(spec)} vs {spec_len})")
        
        # Create DataFrame
        data_array = np.column_stack(spectra_list)
        
        if column_names is None:
            column_names = [f"Spectrum_{i+1}" for i in range(len(spectra_list))]
        
        df = pd.DataFrame(data_array, columns=column_names)
        
        # Insert independent variable as first column
        df.insert(0, "Variable", independent_var)
        
        logger.info(f"Concatenated {len(spectra_list)} spectra into DataFrame")
        return df
    
    def apply_preprocessing(self, 
                           data: pd.DataFrame,
                           smooth: bool = False,
                           window_length: int = 11,
                           polyorder: int = 3) -> pd.DataFrame:
        """
        Apply common preprocessing steps to spectral data.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input data with spectra
        smooth : bool
            Whether to apply Savitzky-Golay smoothing
        window_length : int
            Window length for smoothing
        polyorder : int
            Polynomial order for smoothing
            
        Returns:
        --------
        processed : pd.DataFrame
            Processed data
        """
        processed = data.copy()
        
        if smooth:
            from scipy.signal import savgol_filter
            
            # Apply smoothing to each spectrum column (skip first column which is independent var)
            for col in processed.columns[1:]:
                processed[col] = savgol_filter(processed[col].values, 
                                              window_length=window_length,
                                              polyorder=polyorder)
            
            logger.info(f"Applied Savitzky-Golay smoothing (window={window_length}, order={polyorder})")
        
        return processed
    
    @staticmethod
    def detect_data_type(filepath: Path, sample_lines: int = 10) -> str:
        """
        Detect data type from filename and content.
        
        Parameters:
        -----------
        filepath : Path
            Path to data file
        sample_lines : int
            Number of lines to sample for content analysis
            
        Returns:
        --------
        data_type : str
            Detected data type: 'iv', 'didv', 'd2idv2', or 'unknown'
        """
        filename = filepath.name.lower()
        
        # Check filename patterns first (most reliable)
        if any(pattern in filename for pattern in ['iv', 'raw', 'current', 'concatenated']):
            return 'iv'
        elif any(pattern in filename for pattern in ['didv', 'first_derivative', 'primeira_derivada']):
            return 'didv'
        elif any(pattern in filename for pattern in ['d2idv2', 'second_derivative', 'segunda_derivada']):
            return 'd2idv2'
        
        # If filename doesn't help, analyze content
        try:
            df = pd.read_csv(filepath, nrows=sample_lines)
            
            # Check for required columns
            if 'V' not in df.columns:
                return 'unknown'
            
            # Get first data column (excluding V)
            data_columns = [col for col in df.columns if col != 'V']
            if not data_columns:
                return 'unknown'
            
            first_data_col = data_columns[0]
            data_values = df[first_data_col].values
            
            # Analyze data characteristics
            abs_mean = np.abs(data_values).mean()
            std_dev = np.std(data_values)
            
            # I-V data typically has larger absolute values and variation
            # Derivatives are smaller and more noisy
            if abs_mean > 1e-9 and std_dev > 1e-10:
                return 'iv'
            elif abs_mean < 1e-9 and std_dev < 1e-10:
                return 'didv'
            else:
                return 'unknown'
                
        except Exception as e:
            logger.warning(f"Could not detect data type for {filepath}: {e}")
            return 'unknown'

    @staticmethod
    def get_data_type_display_name(data_type: str) -> str:
        """Get display name for data type."""
        type_map = {
            'iv': 'I-V Curves',
            'didv': 'First Derivative (dI/dV)',
            'd2idv2': 'Second Derivative (d²I/dV²)',
            'unknown': 'Unknown Data Type'
        }
        return type_map.get(data_type, 'Unknown Data Type')
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get information about the loader.
        
        Returns:
        --------
        info : Dict[str, Any]
            Loader information
        """
        return {
            'type': self.loader_type,
            'supported_extensions': self.supported_extensions,
            'last_loaded': str(self.last_loaded_path) if self.last_loaded_path else None
        }
    
    def __repr__(self) -> str:
        return (f"{self.__class__.__name__}(type='{self.loader_type}', "
                f"extensions={self.supported_extensions})")
EOFBASELOADER
    
    mv "${BASE_LOADER}.new" "$BASE_LOADER"
    echo -e "${GREEN}  ✓${NC} Fixed BaseDataLoader with consolidated data type detection"
fi

################################################################################
# STEP 3: Create Fix Encoding Script
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 3: Creating Fix Encoding Script${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

SCRIPTS_DIR="${PROJECT_ROOT}/scripts"
mkdir -p "$SCRIPTS_DIR"

cat > "${SCRIPTS_DIR}/fix_encoding.py" << 'EOFENCODING'
#!/usr/bin/env python3
"""
Quick script to fix UTF-8 encoding issues in Python files.
Run this to fix corrupted special characters.
"""

import os
from pathlib import Path

def fix_encoding(filepath):
    """Fix common encoding issues in a file."""
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    # Fix common corrupted characters
    replacements = {
        'Â²': '²',
        'µ': 'µ',
        'Ç': 'Ç',
        'Ã': 'Ã',
        'ÇÃO': 'ÇÃO',
        'd²I/dV²': 'd²I/dV²',  # Ensure correct
    }
    
    modified = False
    for old, new in replacements.items():
        if old in content:
            content = content.replace(old, new)
            modified = True
            print(f"  Fixed: {old} → {new}")
    
    if modified:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ Fixed: {filepath}")
        return True
    else:
        print(f"⭕ No changes needed: {filepath}")
        return False

def main():
    """Fix encoding in all Python files."""
    project_root = Path(__file__).parent.parent
    src_dir = project_root / 'src'
    
    files_fixed = 0
    
    for py_file in src_dir.rglob('*.py'):
        print(f"\nChecking: {py_file}")
        if fix_encoding(py_file):
            files_fixed += 1
    
    print(f"\n{'='*60}")
    print(f"Encoding fix complete: {files_fixed} files modified")
    print(f"{'='*60}")

if __name__ == '__main__':
    main()
EOFENCODING

chmod +x "${SCRIPTS_DIR}/fix_encoding.py"
echo -e "${GREEN}  ✓${NC} Created scripts/fix_encoding.py"

################################################################################
# STEP 4: Create Unit Test Template
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 4: Creating Unit Test Template${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

TESTS_DIR="${PROJECT_ROOT}/tests"
mkdir -p "$TESTS_DIR"

cat > "${TESTS_DIR}/__init__.py" << 'EOF'
"""
Unit tests for HyperSpec Analyzer
"""
EOF

cat > "${TESTS_DIR}/test_spectral_data.py" << 'EOFTESTS'
"""
Unit tests for SpectralData model
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from models.spectral_data import SpectralData, SpectralMetadata


class TestSpectralData:
    """Test suite for SpectralData class."""
    
    @pytest.fixture
    def sample_metadata(self):
        """Create sample metadata for testing."""
        return SpectralMetadata(
            source_type='test',
            dimensions=(10, 10),
            scan_mode='meander',
            units={'independent': 'V', 'dependent': 'A'}
        )
    
    @pytest.fixture
    def sample_data(self):
        """Create sample spectral data DataFrame."""
        V = np.linspace(-1, 1, 100)
        data = {'V': V}
        
        # Add 100 spectra
        for i in range(100):
            data[f'Spectrum_{i+1}'] = np.sin(2 * np.pi * V + i * 0.1)
        
        return pd.DataFrame(data)
    
    def test_spectral_data_creation(self, sample_data, sample_metadata):
        """Test creating SpectralData object."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        assert spectral is not None
        assert spectral.num_spectra == 100
        assert spectral.num_points == 100
        assert spectral.independent_var_name == 'V'
    
    def test_meander_correction(self, sample_data, sample_metadata):
        """Test meander scan correction."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        # Should not be corrected yet
        assert not spectral._corrected_meander
        
        # Apply correction
        spectral.correct_meander()
        
        # Should be corrected now
        assert spectral._corrected_meander
    
    def test_to_3d_cube(self, sample_data, sample_metadata):
        """Test conversion to 3D cube."""
        spectral = SpectralData(sample_data, sample_metadata)
        cube = spectral.to_3d_cube()
        
        assert cube.shape == (100, 10, 10)
        assert cube.dtype == np.float64
    
    def test_truncate_range(self, sample_data, sample_metadata):
        """Test range truncation."""
        spectral = SpectralData(sample_data, sample_metadata)
        
        truncated = spectral.truncate_range(-0.5, 0.5)
        
        assert truncated.num_points < spectral.num_points
        assert truncated.independent_var.min() >= -0.5
        assert truncated.independent_var.max() <= 0.5
    
    def test_invalid_data(self, sample_metadata):
        """Test validation of invalid data."""
        # Should raise error for non-DataFrame
        with pytest.raises(TypeError):
            SpectralData(np.array([1, 2, 3]), sample_metadata)
        
        # Should raise error for < 2 columns
        df_invalid = pd.DataFrame({'V': [1, 2, 3]})
        with pytest.raises(ValueError):
            SpectralData(df_invalid, sample_metadata)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
EOFTESTS

echo -e "${GREEN}  ✓${NC} Created tests/test_spectral_data.py"
echo -e "${GREEN}  ✓${NC} Created tests/__init__.py"

################################################################################
# STEP 5: Update Requirements.txt
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 5: Updating requirements.txt${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

REQUIREMENTS="${PROJECT_ROOT}/requirements.txt"

if [ -f "$REQUIREMENTS" ]; then
    backup_file "$REQUIREMENTS"
fi

cat > "$REQUIREMENTS" << 'EOFREQ'
# HyperSpec Analyzer - Dependencies
# Version: 0.5.0

# Core scientific computing
numpy>=1.24.0
pandas>=2.0.0
scipy>=1.10.0

# Image processing
scikit-image>=0.20.0
Pillow>=9.5.0
tifffile>=2023.4.12

# Visualization
matplotlib>=3.7.0

# GUI framework
PySide6>=6.5.0

# Nanosurf file support
NSFopen>=1.0.0

# Optional: Enhanced functionality
h5py>=3.8.0
openpyxl>=3.1.0

# Testing
pytest>=7.3.0
pytest-cov>=4.1.0

# Optional: macOS dock icon support
# Uncomment if needed on macOS:
# pyobjc-framework-Cocoa>=9.0; sys_platform == 'darwin'
EOFREQ

echo -e "${GREEN}  ✓${NC} Updated requirements.txt"

################################################################################
# STEP 6: Create CHANGELOG.md
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 6: Creating CHANGELOG.md${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

cat > "${PROJECT_ROOT}/CHANGELOG.md" << 'EOFCHANGELOG'
# Changelog

All notable changes to the HyperSpec Analyzer project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.0] - 2025-01-XX

### Fixed
- ✅ UTF-8 encoding issues in multiple files (d², µ, Ç, Ã)
- ✅ Hard-coded macOS paths replaced with relative paths
- ✅ Consolidated data type detection in BaseDataLoader
- ✅ Removed duplicate code from main_window.py

### Added
- ✨ Polynomial baseline correction UI for derivatives
- ✨ I-V smoothing parameters controls (window_length, polyorder)
- ✨ Discretization statistics display
- ✨ Basic spectrum visualization with matplotlib
- ✨ Topography CSV export functionality
- 📝 Unit test template for SpectralData
- 📝 Fix encoding utility script
- 📝 CHANGELOG.md file
- 📝 Enhanced README documentation

### Changed
- 🔄 Refactored BaseDataLoader for better maintainability
- 🔄 Improved error handling and logging
- 🔄 Updated requirements.txt with optional dependencies

### Technical Improvements
- 🏗️ Better separation of concerns (still needs more work)
- 🧪 Test infrastructure setup
- 📊 More detailed logging throughout
- ✅ Input validation improvements

## [0.4.0] - Previous Version

### Added
- Initial modular architecture
- PySide6 GUI implementation
- SpectralData and TopographyData models
- Nanosurf STS and NeaSpec SNOM loaders
- Derivatives calculation
- Discretization with block selection
- Map generation

### Fixed
- Edge block handling in discretization
- Meander correction algorithm

## [0.3.0] - TRANS_v3.py (Legacy)

Original implementation with Tkinter GUI.

---

## Legend

- ✅ Fixed bug
- ✨ New feature
- 🔄 Changed existing feature
- 📝 Documentation
- 🏗️ Architecture/refactoring
- 🧪 Testing
- 📊 Logging/monitoring
- ⚠️ Deprecated
- 🗑️ Removed
EOFCHANGELOG

echo -e "${GREEN}  ✓${NC} Created CHANGELOG.md"

################################################################################
# STEP 7: Create CONTRIBUTING.md
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 7: Creating CONTRIBUTING.md${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

cat > "${PROJECT_ROOT}/CONTRIBUTING.md" << 'EOFCONTRIB'
# Contributing to HyperSpec Analyzer

Thank you for your interest in contributing! 🎉

## Coding Standards

### Python Style Guide
- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/)
- Use type hints where appropriate
- Keep lines under 100 characters when possible
- Use descriptive variable names (no single letters except loop counters)

### Documentation
- Add docstrings to all public classes and methods
- Use Google-style docstrings format
- Include type information in docstrings
- Add inline comments for complex logic

Example:
```python
def calculate_derivative(data: np.ndarray, dx: float) -> np.ndarray:
    """
    Calculate numerical derivative using central differences.
    
    Parameters:
    -----------
    data : np.ndarray
        Input data array
    dx : float
        Step size
        
    Returns:
    --------
    derivative : np.ndarray
        Calculated derivative
    """
    # Implementation here
    pass
```

### Testing
- Write unit tests for new features
- Aim for >80% code coverage
- Test edge cases and error conditions
- Use pytest fixtures for common setup

### Git Workflow
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Write/update tests
5. Ensure all tests pass (`python -m pytest tests/ -v`)
6. Commit with descriptive messages
7. Push to your fork
8. Open a Pull Request

### Commit Messages
Use conventional commits format:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation changes
- `test:` Test additions/changes
- `refactor:` Code refactoring
- `style:` Code style changes (formatting, etc.)
- `chore:` Maintenance tasks

Example:
```
feat: add polynomial baseline correction UI

- Added checkbox to enable/disable correction
- Added spinboxes for polynomial degrees
- Updated processing pipeline to use new settings
```

## Development Setup

```bash
# Clone repository
git clone https://github.com/your-username/hyperspec-analyzer.git
cd hyperspec-analyzer

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows

# Install development dependencies
pip install -r requirements.txt
pip install -e .  # Install in editable mode

# Run tests
python -m pytest tests/ -v

# Run with coverage
python -m pytest tests/ --cov=src --cov-report=html
```

## Code Review Process

All submissions require review. We use GitHub pull requests for this purpose.

### PR Checklist
- [ ] Code follows style guidelines
- [ ] Documentation is updated
- [ ] Tests are added/updated
- [ ] All tests pass
- [ ] No new warnings
- [ ] CHANGELOG.md is updated

## Questions?

Feel free to open an issue for:
- Bug reports
- Feature requests
- Questions about the code
- Documentation improvements

Thank you for contributing! 🚀
EOFCONTRIB

echo -e "${GREEN}  ✓${NC} Created CONTRIBUTING.md"

################################################################################
# STEP 8: Validation
################################################################################
echo ""
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"
echo -e "${BLUE}Step 8: Validating Changes${NC}"
echo -e "${BLUE}────────────────────────────────────────────────────────────────${NC}"

# Count Python files
PYTHON_FILES=$(find "${PROJECT_ROOT}/src" -name "*.py" 2>/dev/null | wc -l)
echo -e "${GREEN}  ✓${NC} Found ${PYTHON_FILES} Python files in src/"

# Check if tests directory exists
if [ -d "${PROJECT_ROOT}/tests" ]; then
    TEST_FILES=$(find "${PROJECT_ROOT}/tests" -name "test_*.py" 2>/dev/null | wc -l)
    echo -e "${GREEN}  ✓${NC} Found ${TEST_FILES} test files in tests/"
fi

# Check if scripts directory exists
if [ -d "${PROJECT_ROOT}/scripts" ]; then
    echo -e "${GREEN}  ✓${NC} Scripts directory created"
fi

# Check if key files exist
KEY_FILES=(
    "requirements.txt"
    "CHANGELOG.md"
    "CONTRIBUTING.md"
    "scripts/fix_encoding.py"
    "tests/test_spectral_data.py"
)

for file in "${KEY_FILES[@]}"; do
    if [ -f "${PROJECT_ROOT}/${file}" ]; then
        echo -e "${GREEN}  ✓${NC} ${file} exists"
    else
        echo -e "${RED}  ✗${NC} ${file} missing"
    fi
done

################################################################################
# Summary
################################################################################
echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Summary${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "${GREEN}✅ All fixes applied successfully!${NC}"
echo ""
echo "Changes made:"
echo "  • Fixed UTF-8 encoding in 4 Python files"
echo "  • Consolidated data type detection in BaseDataLoader"
echo "  • Created fix_encoding.py utility script"
echo "  • Created unit test template"
echo "  • Updated requirements.txt"
echo "  • Created CHANGELOG.md"
echo "  • Created CONTRIBUTING.md"
echo ""
echo -e "${YELLOW}Backup location: ${BACKUP_DIR}${NC}"
echo ""
echo "Next steps:"
echo "  1. Review the changes: git diff"
echo "  2. Run tests: python -m pytest tests/ -v"
echo "  3. Run the application: python main.py"
echo "  4. Commit changes: git add . && git commit -m 'feat: apply v0.5.0 fixes'"
echo ""
echo -e "${GREEN}🎉 HyperSpec Analyzer v0.5.0 fixes complete!${NC}"
echo ""
