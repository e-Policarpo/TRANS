# Como Aplicar os Fixes v0.5.0

Este documento explica como usar o script `apply_fixes.sh` para aplicar todas as correções documentadas em `code_analysis.md` e `quick_fixes.md`.

## ⚠️ IMPORTANTE: Backup

O script **automaticamente cria backups** de todos os arquivos modificados em:
```
backup_YYYYMMDD_HHMMSS/
```

Se algo der errado, você pode restaurar os arquivos originais dessa pasta.

## 📋 O Que o Script Faz

### 1. Correções de Encoding UTF-8 ✅
Corrige caracteres especiais corrompidos em:
- `src/processing/derivatives.py` (² ao invés de Â²)
- `src/processing/map_generator.py` (CORREÇÃO ao invés de CORREÃ‡ÃƒO)
- `src/data_loaders/neaspec_snom_loader.py` (µm ao invés de Âµm)
- `src/processing/iv_processor.py` (² ao invés de Â²)

### 2. BaseDataLoader - Consolidação de Código ✅
- Remove código duplicado
- Consolida detecção de tipo de dados em um único método estático
- Melhora manutenibilidade

### 3. Scripts Utilitários ✅
Cria:
- `scripts/fix_encoding.py` - Script Python para corrigir encodings futuros
- `scripts/__init__.py` - Inicializador do módulo

### 4. Testes Unitários ✅
Cria:
- `tests/test_spectral_data.py` - Template de testes para SpectralData
- `tests/__init__.py` - Inicializador do módulo de testes

### 5. Documentação ✅
Cria/atualiza:
- `requirements.txt` - Com dependências organizadas e opcionais
- `CHANGELOG.md` - Histórico de versões
- `CONTRIBUTING.md` - Guia de contribuição

## 🚀 Como Usar

### Passo 1: Preparação

```bash
# Navegue até a raiz do projeto
cd /path/to/hyperspec_analyzer

# Dê permissão de execução ao script
chmod +x apply_fixes.sh
```

### Passo 2: Execute o Script

```bash
# Execute o script
./apply_fixes.sh
```

**Saída esperada:**
```
════════════════════════════════════════════════════════════════
  HyperSpec Analyzer - Applying Fixes v0.5.0
════════════════════════════════════════════════════════════════

Project root: /path/to/project

✓ Created backup directory: backup_20250121_143052

────────────────────────────────────────────────────────────────
Step 1: Fixing Encoding Issues
────────────────────────────────────────────────────────────────
  ✓ Backed up: derivatives.py
  ✓ Fixed encoding: derivatives.py
  ✓ Backed up: map_generator.py
  ✓ Fixed encoding: map_generator.py
  ...

✅ All fixes applied successfully!
```

### Passo 3: Verificação

```bash
# Verifique as mudanças
git status

# Veja o diff (opcional)
git diff

# Execute os testes
python -m pytest tests/ -v
```

### Passo 4: Execute a Aplicação

```bash
# Ative o ambiente virtual (se usar)
source venv/bin/activate

# Execute a aplicação
python main.py
```

## 🔍 Verificação Manual

### Arquivos que devem ter sido modificados:

```
✅ src/processing/derivatives.py
✅ src/processing/map_generator.py
✅ src/data_loaders/neaspec_snom_loader.py
✅ src/processing/iv_processor.py
✅ src/data_loaders/base_loader.py
✅ requirements.txt
```

### Arquivos que devem ter sido criados:

```
✅ scripts/fix_encoding.py
✅ tests/test_spectral_data.py
✅ tests/__init__.py
✅ CHANGELOG.md
✅ CONTRIBUTING.md
✅ backup_YYYYMMDD_HHMMSS/ (diretório de backup)
```

## 🛠️ Troubleshooting

### Problema: "Permission denied"
```bash
# Solução: Dê permissão de execução
chmod +x apply_fixes.sh
```

### Problema: "Command not found: perl"
```bash
# Solução: Instale perl
# macOS (já vem instalado)
# Ubuntu/Debian:
sudo apt-get install perl
# Fedora:
sudo dnf install perl
```

### Problema: Script não encontra os arquivos
```bash
# Solução: Execute da raiz do projeto
cd /path/to/hyperspec_analyzer
./apply_fixes.sh
```

### Problema: Encoding ainda incorreto após script
```bash
# Solução: Execute o script Python de correção
python scripts/fix_encoding.py
```

## 📊 Checklist de Validação

Após executar o script, verifique:

- [ ] Nenhum erro durante execução
- [ ] Backup criado com timestamp
- [ ] Caracteres especiais corretos (d², µm, CORREÇÃO)
- [ ] `git diff` mostra mudanças esperadas
- [ ] Testes executam sem erros (`pytest tests/`)
- [ ] Aplicação inicia normalmente (`python main.py`)
- [ ] Sem warnings sobre encoding

## 🔄 Como Reverter

Se precisar desfazer as mudanças:

```bash
# Encontre o diretório de backup
ls -la | grep backup_

# Restaure os arquivos
cp backup_20250121_143052/* src/processing/
cp backup_20250121_143052/base_loader.py src/data_loaders/
cp backup_20250121_143052/requirements.txt .

# Ou use git para resetar
git checkout -- .
```

## 📝 Notas Importantes

1. **O script é idempotente**: Pode ser executado múltiplas vezes sem problemas
2. **Backups são cumulativos**: Cada execução cria um novo diretório de backup
3. **Git-friendly**: Todas as mudanças podem ser revisadas com `git diff`
4. **Não modifica main_window.py**: Este arquivo já foi corrigido manualmente

## 🎯 Próximos Passos

Após aplicar os fixes:

1. **Revise as mudanças**: `git diff`
2. **Execute os testes**: `pytest tests/ -v`
3. **Teste a aplicação**: `python main.py`
4. **Commit as mudanças**:
   ```bash
   git add .
   git commit -m "feat: apply v0.5.0 fixes - encoding, tests, docs"
   ```
5. **Continue desenvolvimento**: Veja CHANGELOG.md para próximas features

## ❓ Precisa de Ajuda?

- 📖 Leia: `code_analysis.md` - Análise completa do código
- 📖 Leia: `quick_fixes.md` - Detalhes de cada correção
- 🐛 Issues: Abra uma issue no GitHub
- 📧 Email: [seu-email-aqui]

---

**Versão**: 0.5.0  
**Data**: Janeiro 2025  
**Autor**: Eduarda Policarpo 🏳️‍⚧️
