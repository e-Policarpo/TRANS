#!/bin/bash

################################################################################
# HyperSpec Analyzer - Quick Test Script
# Version: 0.5.0
# 
# Quick sanity tests to run before committing fixes
#
# Usage: ./quick_test.sh
################################################################################

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

PROJECT_ROOT="${PROJECT_ROOT:-$(pwd)}"

echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  HyperSpec Analyzer - Quick Tests${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

FAILED=0

################################################################################
# Test 1: Python Syntax
################################################################################
echo -e "${BLUE}Test 1: Python Syntax Check${NC}"
echo "Checking all Python files for syntax errors..."

SYNTAX_ERRORS=0
for file in $(find "$PROJECT_ROOT/src" -name "*.py"); do
    if ! python3 -m py_compile "$file" 2>/dev/null; then
        echo -e "${RED}✗${NC} Syntax error in: $file"
        SYNTAX_ERRORS=$((SYNTAX_ERRORS + 1))
    fi
done

if [ $SYNTAX_ERRORS -eq 0 ]; then
    echo -e "${GREEN}✓${NC} All Python files have valid syntax"
else
    echo -e "${RED}✗${NC} Found $SYNTAX_ERRORS files with syntax errors"
    FAILED=$((FAILED + 1))
fi
echo ""

################################################################################
# Test 2: Import Check
################################################################################
echo -e "${BLUE}Test 2: Import Check${NC}"
echo "Checking if main modules can be imported..."

cd "$PROJECT_ROOT"

# Try to import main window
if python3 -c "import sys; sys.path.insert(0, 'src'); from ui.main_window import MainWindow" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} MainWindow imports successfully"
else
    echo -e "${RED}✗${NC} Failed to import MainWindow"
    FAILED=$((FAILED + 1))
fi

# Try to import spectral data
if python3 -c "import sys; sys.path.insert(0, 'src'); from models.spectral_data import SpectralData" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} SpectralData imports successfully"
else
    echo -e "${RED}✗${NC} Failed to import SpectralData"
    FAILED=$((FAILED + 1))
fi

# Try to import base loader
if python3 -c "import sys; sys.path.insert(0, 'src'); from data_loaders.base_loader import BaseDataLoader" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} BaseDataLoader imports successfully"
else
    echo -e "${RED}✗${NC} Failed to import BaseDataLoader"
    FAILED=$((FAILED + 1))
fi

echo ""

################################################################################
# Test 3: Encoding Verification
################################################################################
echo -e "${BLUE}Test 3: Encoding Verification${NC}"
echo "Checking for bad encoding patterns..."

BAD_ENCODINGS=0

# Check for Â² (should be ²)
if grep -r "Â²" "$PROJECT_ROOT/src" 2>/dev/null; then
    echo -e "${RED}✗${NC} Found bad encoding: Â²"
    BAD_ENCODINGS=$((BAD_ENCODINGS + 1))
fi

# Check for Âµ (should be µ)
if grep -r "µ" "$PROJECT_ROOT/src" 2>/dev/null; then
    echo -e "${RED}✗${NC} Found bad encoding: µ"
    BAD_ENCODINGS=$((BAD_ENCODINGS + 1))
fi

if [ $BAD_ENCODINGS -eq 0 ]; then
    echo -e "${GREEN}✓${NC} No bad encoding patterns found"
else
    echo -e "${RED}✗${NC} Found $BAD_ENCODINGS bad encoding patterns"
    echo -e "${YELLOW}  Tip: Run 'python scripts/fix_encoding.py'${NC}"
    FAILED=$((FAILED + 1))
fi
echo ""

################################################################################
# Test 4: File Structure
################################################################################
echo -e "${BLUE}Test 4: File Structure${NC}"
echo "Verifying project structure..."

MISSING_FILES=0

REQUIRED_FILES=(
    "src/models/spectral_data.py"
    "src/data_loaders/base_loader.py"
    "src/processing/derivatives.py"
    "src/ui/main_window.py"
    "main.py"
    "requirements.txt"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$PROJECT_ROOT/$file" ]; then
        echo -e "${RED}✗${NC} Missing file: $file"
        MISSING_FILES=$((MISSING_FILES + 1))
    fi
done

if [ $MISSING_FILES -eq 0 ]; then
    echo -e "${GREEN}✓${NC} All required files present"
else
    echo -e "${RED}✗${NC} Missing $MISSING_FILES required files"
    FAILED=$((FAILED + 1))
fi
echo ""

################################################################################
# Test 5: Git Status
################################################################################
echo -e "${BLUE}Test 5: Git Status${NC}"
echo "Checking git repository status..."

if git rev-parse --git-dir > /dev/null 2>&1; then
    UNSTAGED=$(git diff --name-only | wc -l)
    STAGED=$(git diff --cached --name-only | wc -l)
    UNTRACKED=$(git ls-files --others --exclude-standard | wc -l)
    
    echo -e "Unstaged changes: ${YELLOW}$UNSTAGED${NC}"
    echo -e "Staged changes: ${GREEN}$STAGED${NC}"
    echo -e "Untracked files: ${YELLOW}$UNTRACKED${NC}"
    
    if [ $UNSTAGED -gt 0 ]; then
        echo ""
        echo -e "${YELLOW}Unstaged files:${NC}"
        git diff --name-only | head -10
    fi
    
    if [ $UNTRACKED -gt 0 ]; then
        echo ""
        echo -e "${YELLOW}Untracked files:${NC}"
        git ls-files --others --exclude-standard | head -10
    fi
else
    echo -e "${YELLOW}⚠${NC} Not a git repository"
fi
echo ""

################################################################################
# Test 6: Unit Tests (Optional)
################################################################################
echo -e "${BLUE}Test 6: Unit Tests (Optional)${NC}"

if command -v pytest &> /dev/null; then
    echo "Running pytest..."
    
    if [ -d "$PROJECT_ROOT/tests" ]; then
        cd "$PROJECT_ROOT"
        if pytest tests/ -v --tb=short 2>/dev/null; then
            echo -e "${GREEN}✓${NC} All tests passed"
        else
            echo -e "${YELLOW}⚠${NC} Some tests failed (non-critical)"
        fi
    else
        echo -e "${YELLOW}⚠${NC} No tests directory found"
    fi
else
    echo -e "${YELLOW}⚠${NC} pytest not installed (skipping tests)"
    echo "  Install with: pip install pytest"
fi
echo ""

################################################################################
# Summary
################################################################################
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Test Summary${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✅ All critical tests passed!${NC}"
    echo ""
    echo "You can safely commit your changes:"
    echo "  git add ."
    echo "  git commit -m 'feat: apply v0.5.0 fixes'"
    echo ""
    exit 0
else
    echo -e "${RED}❌ $FAILED critical tests failed${NC}"
    echo ""
    echo "Please fix the issues above before committing."
    echo ""
    echo "Common fixes:"
    echo "  • Encoding issues: python scripts/fix_encoding.py"
    echo "  • Import errors: check your PYTHONPATH"
    echo "  • Missing files: re-run apply_fixes.sh"
    echo ""
    exit 1
fi
